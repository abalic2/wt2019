window.onload = function () {
	
	var periodicna = {dan: 3, semestar : "zimski", pocetak: "13:59", kraj:"14:59", naziv: "VA-01", predavac:"Ime Prezi"};
    var vanredna = {datum:"11.12.2019", pocetak:"15:00", kraj:"17:00", naziv: "MA", predavac:"Imenko Prezimenko"};
	var trenutni = new Date();
	trenutni
    mjesec = trenutni.getMonth();
	var godina = trenutni.getYear();
	var dan = periodicna.dan;
	Kalendar.ucitajPodatke(periodicna,vanredna);
	Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), mjesec, periodicna.sala, periodicna.pocetak, periodicna.kraj);
}

let Kalendar = (function(){
	// definisimo globalne varijable 
	kalendarRef = document.getElementsByClassName("kalendar_mjesec");
	trenutni = new Date();
	mjesec = trenutni.getMonth();
	global_periodicna = {};
    global_vanredna = {};

function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj){
	
	var godina = trenutni.getYear();
	var semestar = "";
	var vdan = "";
	var vmjesec = "";
	var mjesecImena = ["Januar","Februar","Mart","April","Maj","Juni","Juli","August","Septembar","Oktobar","Novembar", "Decembar"];
	// definisimo listu dan_zaglavlje u koju ćemo ispisivati dane 
	var dan_zaglavlje = document.querySelectorAll(".sedmica .dan_zaglavlje");
	var dan_sadrzaj = document.querySelectorAll(".sedmica .dan_sadrzaj");
	if (global_periodicna.semestar=="zimski") {
		var zmjesec = [9, 10, 11, 0];
	}
	if (global_periodicna.semestar=="ljetni") {
		var ljmjesec = [1, 2, 3, 4, 5];
	}
	
	var pdan = global_periodicna.dan;
	
	if (global_vanredna.datum[0]=="0")
	{
		 vdan = global_vanredna.datum[1];
	}
	else {
		 vdan = global_vanredna.datum[0]+global_vanredna.datum[1];
	}
	
	if (global_vanredna.datum[3]=="0")
	{
		 vmjesec = global_vanredna.datum[4];
	}
		
	else vmjesec = global_vanredna.datum[3]+global_vanredna.datum[4];
	
	vmjesec = vmjesec -1;
	
	// prilikom promjene mjeseca vrati na zadanu boju
	for (var i = 0; i <dan_zaglavlje.length; i++) {
		dan_sadrzaj[i].style.backgroundColor = "green";	
	}

	/* oboji vanredne - vanredno zauzeće vrijedi samo za dati datum i vrijeme */ 
	for (var i = 0; i <dan_zaglavlje.length; i++) {
		
		if(document.getElementsByTagName("h2")[0].innerHTML == mjesecImena[vmjesec])
		{
			if (dan_zaglavlje[i].innerHTML==vdan) {
					dan_sadrzaj[i].style.backgroundColor = "red";
			}
		}
	}
	
	/* oboji periodicna ponavlja svake sedmice određenog semestra */ 
	if (global_periodicna.semestar=="zimski") 
	{
		if(mjesec==9 || mjesec==10 || mjesec==11)
		{
			for (var i = 0; i <dan_zaglavlje.length; i++) {
				if(dan_sadrzaj[i].style.backgroundColor != "red") dan_sadrzaj[i].style.backgroundColor = "green";	
			}
			
			for (var i = 0; i <dan_zaglavlje.length; i++) {
					
					if(i==pdan) {
						for(var j=i; j<dan_zaglavlje.length;)
						{
							dan_sadrzaj[j].style.backgroundColor = "yellow";
							j=j+7;
						}
					j=0;
					}
			}
		}
	}
	
	 /*oboji periodicna ponavlja svake sedmice određenog semestra */ 
	if (global_periodicna.semestar=="ljetni" && godina=="2020") 
	{
		if(mjesec==1 || mjesec==2 || mjesec==3 || mjesec==4 || mjesec==5)
		{
			{
			for (var i = 0; i <dan_zaglavlje.length; i++) {
				if(dan_sadrzaj[i].style.backgroundColor != "red") dan_sadrzaj[i].style.backgroundColor = "green";	
			}
			
			for (var i = 0; i <dan_zaglavlje.length; i++) {
					
					if(i==pdan) {
						for(var j=i; j<dan_zaglavlje.length;)
						{
							dan_sadrzaj[j].style.backgroundColor = "blue";
							j=j+7;
						}
					j=0;
					}
			}
		}
		}
	}
}

function ucitajPodatkeImpl(periodicna, vanredna){

	global_periodicna = {dan: periodicna.dan, semestar : periodicna.semestar, pocetak: periodicna.pocetak, kraj: periodicna.kraj, naziv: periodicna.naziv, predavac: periodicna.predavac};
	global_vanredna = {datum:vanredna.datum, pocetak:vanredna.pocetak, kraj:vanredna.kraj, naziv:vanredna.naziv, predavac:vanredna.predavac}; 
}

function iscrtajKalendarImpl(kalendarRef, mjesec){
	
	// definisemo varijable febBrojDana i godina potrebne da izracunamo broj dana u Februaru 
	var febBrojDana = "";
	var godina = trenutni.getYear();
	
	// izracunajmo koliko Februar ima dana 
	if (mjesec == 1){
		if ( (godina%100!=0) && (godina%4==0) || (godina%400==0)){
			febBrojDana = 29;
		}else{
			febBrojDana = 28;
		}
	}
	
	// imena mjeseci i dana u sedmici 
	var mjesecImena = ["Januar","Februar","Mart","April","Maj","Juni","Juli","August","Septembar","Oktobar","Novembar", "Decembar"];
	
	// ispisimo ime mjeseca 
	document.getElementsByTagName("h2")[0].innerHTML = mjesecImena[mjesec];
	
	// koliko dana ima svaki mjesecu 2019. godini
	var daniMjesec = ["31", ""+febBrojDana+"","31","30","31","30","31","31","30","31","30","31"];
	var brojDana = daniMjesec[mjesec];
	
	// definisimo koji dan u sedmici je prvi dan u mjesecu za svaki mjesec 
	var danPocetak = [ "1", "4", "4", "0", "2", "5", "0", "3", "6",  "1",  "4", "6"];
	var pocetakDan = danPocetak[mjesec];
	
	// definisimo listu dan_zaglavlje u koju ćemo ispisivati dane 
	var dan_zaglavlje = document.querySelectorAll(".sedmica .dan_zaglavlje");
	
	// definisimo listu dan_okvir koji cemo prikazivati ili sakrivati u zavisnosti da li je dan validan ili ne
	var dan_okvir = document.querySelectorAll(".sedmica .dan");
	
	var dan = 0;
	for (var i = 0; i <dan_zaglavlje.length; i++) {
		
		if (i>=pocetakDan) {
			
			var item = dan + 1;
		
			if (item >= 1 && item <= brojDana)
			{	
				dan_zaglavlje[i].innerHTML = item;
				dan_okvir[i].style.visibility= "visible";
				dan ++;
			}
			else {
				dan_okvir[i].style.visibility="hidden";
			}
		}
		else {
			dan_okvir[i].style.visibility="hidden";
		}
	}
}

return {
	obojiZauzeca: obojiZauzecaImpl,
	ucitajPodatke: ucitajPodatkeImpl,
	iscrtajKalendar: iscrtajKalendarImpl
}
}());

function todonext(){
	if(mjesec<=10){
		mjesec = mjesec+1;
		Kalendar.iscrtajKalendar(kalendarRef, mjesec);
		//global_periodicna.dan = 1;
		Kalendar.ucitajPodatke(global_periodicna,global_vanredna);
		Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), mjesec, global_periodicna.sala, global_periodicna.pocetak, global_periodicna.kraj);	
		Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), mjesec, global_vanredna.naziv, global_vanredna.pocetak, global_vanredna.kraj);	
	}
}

function todobefore(){
	if(mjesec>0){
		mjesec = mjesec-1;
		Kalendar.iscrtajKalendar(kalendarRef, mjesec);	
		//global_periodicna.dan = 3;
		Kalendar.ucitajPodatke(global_periodicna,global_vanredna);
		Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), mjesec, global_periodicna.sala, global_periodicna.pocetak, global_periodicna.kraj);
		Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), mjesec, global_vanredna.naziv, global_vanredna.pocetak, global_vanredna.kraj);	
	}
}
function todo(){
	var periodicna = {};
	var vanredna = {};
	periodicna.naziv = document.getElementsByName("lista")[0].value;
	vanredna.naziv = document.getElementsByName("lista")[0].value;
	periodicna.pocetak = document.getElementsByName("pocetak")[0].value;
	periodicna.kraj = document.getElementsByName("kraj")[0].value;
	vanredna.pocetak = document.getElementsByName("pocetak")[0].value;
	vanredna.kraj = document.getElementsByName("kraj")[0].value;
	vanredna.datum = "17.10.2019";
	periodicna.mjesec = 12;
	Kalendar.ucitajPodatke(periodicna,vanredna);
	Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), periodicna.mjesec, periodicna.sala, periodicna.pocetak, periodicna.kraj);	
	Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), mjesec, vanredna.naziv, vanredna.pocetak, vanredna.kraj);
}

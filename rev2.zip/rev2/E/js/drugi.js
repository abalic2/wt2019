//mozemo i ovo mozda u modul stavit kasnije
var prikazaniMjesec,divKalendar,dSljedeci,dPrethodni,sSale,iPocetak,iKraj;
var sSaleTekst,iPocetakTekst,iKrajTekst;
//dugmadi,elementi i eventi
divKalendar=document.getElementById("kalendar");
prikazaniMjesec=new Date().getMonth();
dSljedeci=document.getElementById("sljedeci");
dPrethodni=document.getElementById("prethodni");
sSale=document.getElementById("sale");
sSaleTekst=sSale.options[sSale.selectedIndex].text;
iPocetak=document.getElementById("pocetak");
iKraj=document.getElementById("kraj");
Kalendar.iscrtajKalendar(divKalendar,prikazaniMjesec);
if(prikazaniMjesec==11) {dSljedeci.disabled=true;}
if(prikazaniMjesec==0) {dPrethodni.disabled=true;}
//eventi
dSljedeci.addEventListener("click",function(ev){
  prikazaniMjesec++;
  Kalendar.iscrtajKalendar(divKalendar,prikazaniMjesec);
  if(prikazaniMjesec==11) {dSljedeci.disabled=true;}
  if(prikazaniMjesec!=0) {dPrethodni.disabled=false;}
  console.log(prikazaniMjesec+" "+sSaleTekst+" "+iPocetakTekst+" "+iKrajTekst);
  if(typeof(iPocetakTekst)!="undefined" && typeof(iKrajTekst)!="undefined")
    Kalendar.obojiZauzeca(divKalendar,prikazaniMjesec,sSaleTekst,iPocetakTekst,iKrajTekst);
},false);
dPrethodni.addEventListener("click",function(ev){
  prikazaniMjesec--;
  Kalendar.iscrtajKalendar(divKalendar,prikazaniMjesec);
  if(prikazaniMjesec==0) {dPrethodni.disabled=true;}
  if(prikazaniMjesec!=11) {dSljedeci.disabled=false;}
  console.log(prikazaniMjesec+" "+sSaleTekst+" "+iPocetakTekst+" "+iKrajTekst);
  if(typeof(iPocetakTekst)!="undefined" && typeof(iKrajTekst)!="undefined")
    Kalendar.obojiZauzeca(divKalendar,prikazaniMjesec,sSaleTekst,iPocetakTekst,iKrajTekst);
},false);
sSale.addEventListener("change",function(ev){
  sSaleTekst=sSale.options[sSale.selectedIndex].text;
  console.log(prikazaniMjesec+" "+sSaleTekst+" "+iPocetakTekst+" "+iKrajTekst);
  if(typeof(iPocetakTekst)!="undefined" && typeof(iKrajTekst)!="undefined")
    Kalendar.obojiZauzeca(divKalendar,prikazaniMjesec,sSaleTekst,iPocetakTekst,iKrajTekst);
},false);
iPocetak.addEventListener("change",function(ev){
  iPocetakTekst=iPocetak.value.split(":");
  iPocetakTekst=iPocetakTekst[0]+":"+iPocetakTekst[1];
  console.log(prikazaniMjesec+" "+sSaleTekst+" "+iPocetakTekst+" "+iKrajTekst);
  if(typeof(iKrajTekst)!="undefined")
    Kalendar.obojiZauzeca(divKalendar,prikazaniMjesec,sSaleTekst,iPocetakTekst,iKrajTekst);
},false);
iKraj.addEventListener("change",function(ev){
  iKrajTekst=iKraj.value.split(":");
  iKrajTekst=iKrajTekst[0]+":"+iKrajTekst[1];
  console.log(prikazaniMjesec+" "+sSaleTekst+" "+iPocetakTekst+" "+iKrajTekst);
  if(typeof(iPocetakTekst)!="undefined")
    Kalendar.obojiZauzeca(divKalendar,prikazaniMjesec,sSaleTekst,iPocetakTekst,iKrajTekst);
},false);
//hardkodirani podaci
var pperiodicna=[{dan:5,semestar:"zimski",pocetak:"12:35",kraj:"15:00",naziv:"0-01",predavac:"Emir"}];
var pvanredna=[{datum:"21.11.2019",pocetak:"12:35",kraj:"15:00",naziv:"0-01",predavac:"Emir"}];
Kalendar.ucitajPodatke(pperiodicna,pvanredna);
//Kalendar.obojiZauzeca(document.getElementById("kalendar"),10,"0-01","12:35","15:00");
//pregeldat imal gresaka, duple deklaracije...;
//kad budem imao vremena kod poboljsat, duplirani->u fje...

const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const path = require("path");
const fs = require("fs");

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.use(bodyParser.json());

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname + "/public/pocetna.html"));
});

app.get("/zauzeca", (req, res) => {
  fs.readFile("zauzeca.json", function(err, podaci) {
    res.send(JSON.parse(podaci.toString()));
  });
});

app.use(
  session({
    secret: "sesija",
    resave: true,
    saveUninitialized: true
  })
);

app.get("/images", function(req, res) {
  fs.readdir("./images", function(err, items) {
    res.write(JSON.stringify(items));
    let sveSlike = [];
    for (let i = 0; i < items.length; i++) {
      let slika = { naziv: items[i], vrijednost: 0 };
      sveSlike.push(slika);
    }
    req.session.images = sveSlike;
    res.send();
  });
});

app.get("/sl", (req, res) => {
  res.sendFile(__dirname + "/images/" + dajMogucuSliku(req.session.images));
});

function dajMogucuSliku(sveSlike) {
  for (let i = 0; i < sveSlike.length; i++) {
    if (sveSlike[i].vrijednost == 0) {
      sveSlike[i].vrijednost = 1;
      return sveSlike[i].naziv;
    }
  }
}

//za zahtjeve sa postmana korisnik moze unijeti bilo sta, zbog toga se mora validirati da li je tijelo zahtjeva u skladu sa trazenim
app.post("/zauzeca", function(req, res) {
  let zahtjev = req.body;

  fs.readFile("zauzeca.json", function(err, data) {
    if (err) throw err;
    let podaci = JSON.parse(data);
    let periodicna = jeLiIspravnaPeriodicna(zahtjev);
    let vanredna = jeLiIspravnaVanredna(zahtjev);
    let mogucePeriodicnoZauzet = false;
    let moguceVanrednoZauzet = false;
    let datumZaIspis;

    if (periodicna) {
      datumZaIspis = "mjesec (periodicno)";
      mogucePeriodicnoZauzet = jeLiMogucePeriodicnoZauzet(zahtjev, podaci);
    }

    if (vanredna) {
      datumZaIspis = "datum " + zahtjev["datum"];
      moguceVanrednoZauzet = jeLiMoguceVanrednoZauzet(zahtjev, podaci);
    }

    if (periodicna && mogucePeriodicnoZauzet) {
      podaci["periodicna"].push(zahtjev);
      let noviPodaci = JSON.stringify(podaci);
      fs.writeFile("zauzeca.json", noviPodaci, function(err) {
        if (err) {
          return console.log(err);
        }
      });
      res.json({ zauzeca: JSON.parse(noviPodaci), err: undefined });
    } else if (vanredna && moguceVanrednoZauzet) {
      podaci["vanredna"].push(zahtjev);
      let noviPodaci = JSON.stringify(podaci);
      fs.writeFile("zauzeca.json", noviPodaci, function(err) {
        if (err) {
          return console.log(err);
        }
      });
      res.json({ zauzeca: JSON.parse(noviPodaci), err: undefined });
    } else {
      let greska =
        "Nije moguće rezervisati salu " +
        zahtjev["naziv"] +
        " za navedeni " +
        datumZaIspis +
        " i termin od " +
        zahtjev["pocetak"] +
        " do " +
        zahtjev["kraj"] +
        "!";
      res.json({ zauzeca: undefined, err: greska });
    }
  });
});

function jeLiMoguceVanrednoZauzet(zahtjev, podaci) {
  let kolonaZauzeca = dajKolonuZauzeca(zahtjev["datum"]);

  //prvo provjerimo da li u vanrednim zauzecima postoji sala sa istim nazivom, istim datumom kao i ona iz zahtjeva
  //te da li se njihova vremena zauzeca poklapaju
  for (let i = 0; i < podaci.vanredna.length; i++) {
    if (
      podaci.vanredna[i].naziv === zahtjev["naziv"] &&
      podaci.vanredna[i].datum == zahtjev["datum"] &&
      kolizijaTermina(
        podaci.vanredna[i].pocetak,
        podaci.vanredna[i].kraj,
        zahtjev["pocetak"],
        zahtjev["kraj"]
      )
    )
      return false;
  }
  let semestarZahtjeva = dajSemestarZahtjeva(zahtjev["datum"]);
  for (let i = 0; i < podaci.periodicna.length; i++) {
    if (
      podaci.periodicna[i].naziv == zahtjev["naziv"] &&
      podaci.periodicna[i].semestar == semestarZahtjeva &&
      kolizijaTermina(
        podaci.vanredna[i].pocetak,
        podaci.vanredna[i].kraj,
        zahtjev["pocetak"],
        zahtjev["kraj"]
      ) &&
      dajKolonuZauzeca(zahtjev["datum"]) == podaci.vanredna[i].dan
    )
      return false;
  }
  return true;
}

function jeLiMogucePeriodicnoZauzet(zahtjev, podaci) {
  for (let i = 0; i < podaci.periodicna.length; i++) {
    if (
      podaci.periodicna[i].naziv == zahtjev["naziv"] &&
      podaci.periodicna[i].semestar == zahtjev["semestar"] &&
      podaci.periodicna[i].dan == zahtjev["dan"] &&
      kolizijaTermina(
        podaci.periodicna[i].pocetak,
        podaci.periodicna[i].kraj,
        zahtjev["pocetak"],
        zahtjev["kraj"]
      )
    )
      return false;
  }
  for (let i = 0; i < podaci.vanredna.length; i++) {
    if (
      podaci.vanredna[i].naziv == zahtjev["naziv"] &&
      dajSemestarZahtjeva(podaci.vanredna[i].datum) == zahtjev["semestar"] &&
      dajKolonuZauzeca(podaci.vanredna[i].datum) == zahtjev["dan"] &&
      kolizijaTermina(
        podaci.vanredna[i].pocetak,
        podaci.vanredna[i].kraj,
        zahtjev["pocetak"],
        zahtjev["kraj"]
      )
    )
      return false;
  }
  return true;
}

//ovdje je mjesec 1 - 12
function dajSemestarZahtjeva(datum) {
  let mjesec = datum.substr(3, 2);
  mjesec = parseInt(mjesec, 10);
  if (mjesec >= 10 || mjesec <= 2) return "zimski";
  if (mjesec >= 3 && mjesec <= 7) return "ljetni";
  return "";
}

//ponedjeljak 1 utorak 2 srijeda 3 ... nedjelja 7
function dajKolonuZauzeca(datum) {
  let dan = datum.substr(0, 2);
  let mjesec = datum.substr(3, 2);
  let godina = datum.substr(6, 4);
  dan = parseInt(dan, 10);
  mjesec = parseInt(mjesec, 10);
  mjesec--;
  godina = parseInt(godina, 10);
  let d = new Date(godina, mjesec, dan);
  let kolona = d.getDay();
  if (kolona == 0) kolona = 7;
  return kolona;
}

function kolizijaTermina(vp, vk, zp, zk) {
  return !(vk < zp || zk < vp);
}

function jeLiIspravnaVanredna(zahtjev) {
  //JEDINI ISPRAVAN FORMAT ZA VANREDNO ZAUZECE:
  //moze i drugim redoslijedom ali ovako mi je u zauzeca.json
  //console.log(kljucevi[0] + " " + kljucevi[1] + " " + kljucevi[2] + " " + kljucevi[3] + " " + kljucevi[4]);
  //datum pocetak kraj naziv predavac
  let kljucevi = Object.keys(zahtjev);
  kljucevi.forEach(element => (element = element.toLowerCase()));

  return (
    kljucevi[0] == "datum" &&
    kljucevi[1] == "pocetak" &&
    kljucevi[2] == "kraj" &&
    kljucevi[3] == "naziv" &&
    kljucevi[4] == "predavac" &&
    kljucevi.length == 5 &&
    zahtjev["datum"] != undefined &&
    zahtjev["pocetak"] != undefined &&
    zahtjev["kraj"] != undefined &&
    zahtjev["naziv"] != undefined &&
    zahtjev["predavac"] != undefined &&
    validirajDatum(zahtjev["datum"]) &&
    validirajVrijeme(zahtjev["pocetak"]) &&
    validirajVrijeme(zahtjev["kraj"]) &&
    zahtjev["pocetak"] < zahtjev["kraj"] &&
    validirajNaziv(zahtjev["naziv"])
  );
}

function jeLiIspravnaPeriodicna(zahtjev) {
  //JEDINI ISPRAVAN FORMAT ZA PERIODICNO ZAUZECE:
  //moze i drugim redoslijedom ali ovako mi je u zauzeca.json
  //console.log(kljucevi[0] + " " + kljucevi[1] + " " + kljucevi[2] + " " + kljucevi[3] + " " + kljucevi[4] + " " kljucevi[5]);
  //dan semestar pocetak kraj naziv predavac
  let kljucevi = Object.keys(zahtjev);
  kljucevi.forEach(element => (element = element.toLowerCase()));
  return (
    kljucevi[0] == "dan" &&
    kljucevi[1] == "semestar" &&
    kljucevi[2] == "pocetak" &&
    kljucevi[3] == "kraj" &&
    kljucevi[4] == "naziv" &&
    kljucevi[5] == "predavac" &&
    kljucevi.length == 6 &&
    zahtjev["dan"] != undefined &&
    zahtjev["semestar"] != undefined &&
    zahtjev["pocetak"] != undefined &&
    zahtjev["kraj"] != undefined &&
    zahtjev["naziv"] != undefined &&
    zahtjev["predavac"] != undefined &&
    validirajDan(zahtjev["dan"]) &&
    validirajSemestar(zahtjev["semestar"]) &&
    validirajVrijeme(zahtjev["pocetak"]) &&
    validirajVrijeme(zahtjev["kraj"]) &&
    zahtjev["pocetak"] < zahtjev["kraj"] &&
    validirajNaziv(zahtjev["naziv"])
  );
}

function validirajDan(dan) {
  dan = parseInt(dan, 10);
  return dan >= 1 && dan <= 7;
}

function validirajSemestar(semestar) {
  return semestar == "ljetni" || semestar == "zimski";
}

//u zauzeca.json format datuma je dd.mm.yyyy
function validirajDatum(datum) {
  let dan = datum.substr(0, 2);
  let mjesec = datum.substr(3, 2);
  let godina = datum.substr(6, 4);
  dan = parseInt(dan, 10);
  mjesec = parseInt(mjesec, 10);
  godina = parseInt(godina, 10);
  return dan >= 0 && dan <= 31 && mjesec >= 0 && mjesec <= 12 && godina >= 2019;
}

//duzina vremena + dvijetacke na sredini
function validirajVrijeme(vrijeme) {
  let sati = vrijeme.substr(0, 2);
  let minute = vrijeme.substr(3, 2);
  sati = parseInt(sati, 10);
  minute = parseInt(minute, 10);
  return sati >= 0 && sati <= 24 && minute >= 0 && minute <= 60;
}

function validirajNaziv(naziv) {
  let sale = [
    "0-01",
    "0-02",
    "0-03",
    "0-04",
    "0-05",
    "0-06",
    "0-07",
    "0-08",
    "0-09",
    "1-01",
    "1-02",
    "1-03",
    "1-04",
    "1-05",
    "1-06",
    "1-07",
    "1-08",
    "1-09",
    "VA1",
    "VA2",
    "MA",
    "EE1",
    "EE2"
  ];
  for (let i = 0; i < sale.length; i++) {
    if (sale[i] === naziv) return true;
  }
  return false;
}

app.listen(8080);

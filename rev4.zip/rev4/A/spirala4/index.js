const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const app = express();

var offset = 0;

//kada se na pocetku dobave sva zauzeca, snime se ovdje
//kad ase doda neko zauzece, takodjer se snimi ovdje
//SVRHA: kada provjeravamo na serverskoj strani unutar index.js da li zauzece vec postoji
//ne moramo dobavljati sva zauzeca opet(2000140 puta), vec samo provjerimo unutar ovog cache-a
//smatram da je mnogo jeftinije i brže u ovom slucaju cuvati ovako u nizu koji se azurira, nego svaki put
//pozivati 3-4 query-a za tebele samo da dobavimo sve i onda opet jos dodatne query-e za upis pri rezervaciji nove sale
var zauzecaCache = {
	vanredna: [],
	periodicna: []
};

app.use("/slike", express.static(__dirname + "/slike"));

app.use("/ikonice", express.static(__dirname + "/ikonice"));

app.use("/stilovi", express.static(__dirname + "/stilovi"));

app.use("/skripte", express.static(__dirname + "/skripte"));

app.use(bodyParser.json());

app.get("/", function(req, res) {
	offset = 0;
	res.sendFile(__dirname + "/stranice/pocetna.html");
});

/* Stranice */
app.get("/sale.html", function(req, res) {
	res.sendFile(__dirname + "/stranice/sale.html");
});

app.get("/unos.html", function(req, res) {
	res.sendFile(__dirname + "/stranice/unos.html");
});
app.get("/rezervacije.html", function(req, res) {
	res.sendFile(__dirname + "/stranice/rezervacije.html");
});
app.get("/osobe.html", function(req, res) {
	res.sendFile(__dirname + "/stranice/osobe.html");
});

app.get("/testoviSpirala4.html", function(req,res){
	res.sendFile(__dirname+ "/stranice/testoviSpirala4.html");
})

/* Pomocne funkcije za provjeru na serverskoj strani da li je zauzece vec prisutno */

function presjekVremena(poc1, kraj1, poc2, kraj2) {
	let ukupMinutePoc1 =
		parseInt(poc1.substr(0, 2)) * 60 + parseInt(poc1.substr(3, 2));
	let ukupMinuteKraj1 =
		parseInt(kraj1.substr(0, 2)) * 60 + parseInt(kraj1.substr(3, 2));

	let ukupMinutePoc2 =
		parseInt(poc2.substr(0, 2)) * 60 + parseInt(poc2.substr(3, 2));
	let ukupMinuteKraj2 =
		parseInt(kraj2.substr(0, 2)) * 60 + parseInt(kraj2.substr(3, 2));
	//drugi pocinje prije nego sto prvi zavrsi i prvi pocinje prije nego sto drugi zavrsi
	//znaci da ova 2 vremena imaju presjekp
	let drugoSadrzanoUPrvom =
		ukupMinutePoc2 < ukupMinuteKraj1 && ukupMinutePoc1 < ukupMinuteKraj2;
	return drugoSadrzanoUPrvom; //refaktoring
}

function dajSvaPeriodicna(periodicna) {
	var rez = [];
	if (periodicna.semestar == "zimski") {
		//oktobar novembar decembar januar
		let prviDatum = new Date("1-1-2020"); //MM-DD-YYYY
		//posebno januar jer nema sad sljedece godine

		//pomjerimo na prvi validan dan i onda ostale
		while (prviDatum.getDay() != (periodicna.dan + 1) % 7) {
			prviDatum.setDate(prviDatum.getDate() + 1);
		}

		while (prviDatum.getMonth() == 0) {
			rez.push({
				datum: new Date(prviDatum),
				pocetak: periodicna.pocetak,
				kraj: periodicna.kraj,
				naziv: periodicna.naziv,
				predavac: periodicna.predavac
			});
			prviDatum.setDate(prviDatum.getDate() + 7);
		}

		//sad radimo ostale mjesece
		prviDatum = new Date("10-1-2020");
		while (prviDatum.getDay() != (periodicna.dan + 1) % 7) {
			prviDatum.setDate(prviDatum.getDate() + 1);
		}
		while (prviDatum.getMonth() >= 9 && prviDatum.getMonth() <= 11) {
			rez.push({
				datum: new Date(prviDatum),
				pocetak: periodicna.pocetak,
				kraj: periodicna.kraj,
				naziv: periodicna.naziv,
				predavac: periodicna.predavac
			});
			prviDatum.setDate(prviDatum.getDate() + 7);
		}
	} else if (periodicna.semestar == "ljetni") {
		//feb mart april maj juni
		prviDatum = new Date("2-1-2020");
		while (prviDatum.getDay() != (periodicna.dan + 1) % 7) {
			prviDatum.setDate(prviDatum.getDate() + 1);
		}
		while (prviDatum.getMonth() >= 1 && prviDatum.getMonth() <= 5) {
			rez.push({
				datum: new Date(prviDatum),
				pocetak: periodicna.pocetak,
				kraj: periodicna.kraj,
				naziv: periodicna.naziv,
				predavac: periodicna.predavac
			});
			prviDatum.setDate(prviDatum.getDate() + 7);
		}
	}
	return rez;
}

function postojiZauzece(pocetak, kraj, sala, datum, periodicna, svaZauzeca) {
	let zauzeca = pretvoriUVanredna(svaZauzeca.periodicna, svaZauzeca.vanredna);
	datum.setHours(0, 0, 0, 0);

	if (periodicna) {
		let semestar =
			datum.getMonth() >= 1 && datum.getMonth() <= 5
				? "ljetni"
				: "zimski";
		let dan = datum.getDay() - 1;
		if (dan < 0) dan = 6;
		let zauzecePeriodicno = {
			dan: dan,
			semestar: semestar,
			pocetak: pocetak,
			kraj: kraj,
			naziv: sala,
			predavac: "Huga Buga"
		};
		/* Pretvorimo periodicno u sva vanredna i provjerimo hoce li ijedno vrijeme kaciti */
		let nizVanrednih = dajSvaPeriodicna(zauzecePeriodicno);

		for (let i = 0; i < nizVanrednih.length; i++) {
			let el = nizVanrednih[i];
			for (let j = 0; j < zauzeca.length; j++) {
				let el2 = zauzeca[j];
				el.datum.setHours(0, 0, 0, 0);
				el2.datum.setHours(0, 0, 0, 0);
				if (
					presjekVremena(
						el.pocetak,
						el.kraj,
						el2.pocetak,
						el2.kraj
					) &&
					el.datum.getTime() == el2.datum.getTime() &&
					el.naziv == el2.naziv
				)
					return 1;
			}
		}
	} else {
		for (let i = 0; i < zauzeca.length; i++) {
			zauzeca[i].datum.setHours(0, 0, 0, 0);
			if (
				presjekVremena(
					zauzeca[i].pocetak,
					zauzeca[i].kraj,
					pocetak,
					kraj
				) &&
				zauzeca[i].datum.getTime() == datum.getTime() &&
				zauzeca[i].naziv == sala
			)
				return 1;
		}
		console.log(zauzeca.length);
	}

	return 0;
}

function pretvoriUVanredna(periodicna, vanredna) {
	//na sva vanredna dodaj jos periodicna kada ih pretvorimo u konkretne vanredne termine pomocu metode dajSvaPeriodicna
	let rez = [];
	vanredna.forEach(el => {
		rez.push({
			datum: new Date(el.datum),
			pocetak: el.pocetak,
			kraj: el.kraj,
			naziv: el.naziv,
			predavac: el.predavac
		});
	});
	periodicna.forEach(el => {
		rez = rez.concat(dajSvaPeriodicna(el));
	});
	return rez;
}

app.get("/sale", function(req, res) {
	console.log("dohvatiSale");
	db.Sala.findAll().then(function(sale) {
		var rez = [];
		for (let i = 0; i < sale.length; i++) {
			rez.push(sale[i].naziv);
		}
		res.send(rez);
		res.end();
	});
});

app.post("/rezervacije", function(req, res) {
	/* Provjera na serveru ali povezana sa centralnom provjerom modula kalendar da ne kopiramo više puta isti kod */
	var tijelo = req.body;
	console.log("DATUM PRIMLJENI " + tijelo.datum);
	let samoDatum = tijelo.datum;
	let imee = tijelo.osoba.split(" ");

	let mjesecc = Number(tijelo.datum.substr(3, 2));
	let dan = Number(tijelo.datum.substr(0, 2));
	let godina = tijelo.datum.substr(6, 4);

	let datumZauzecaSale = new Date(godina, mjesecc - 1, dan);
	console.log("DATUM POSLANI " + datumZauzecaSale);
	if (
		postojiZauzece(
			tijelo.pocetak,
			tijelo.kraj,
			tijelo.sala,
			datumZauzecaSale,
			tijelo.periodicna,
			zauzecaCache
		)
	) {
		res.writeHead(500, { "Content-Type": "text/html" });
		let stringg =
			"Nije moguće rezervisati salu " +
			tijelo.sala +
			" za navedeni datum " +
			datumZauzecaSale.getDate() +
			"/" +
			mjesecc +
			"/2020" +
			" i termin od " +
			tijelo.pocetak +
			" do " +
			tijelo.kraj +
			"! Salu je zauzela osoba: " +
			tijelo.osoba;
		res.write(stringg);
		res.end();
	} else {
		if (!tijelo.periodicna) {
			console.log("DATUM " + samoDatum);
			zauzecaCache.vanredna.push({
				datum: samoDatum,
				pocetak: tijelo.pocetak,
				kraj: tijelo.kraj,
				naziv: tijelo.sala,
				predavac: tijelo.osoba
			});
			//upis u bazu

			db.Termin.create({
				redovni: 0,
				dan: null,
				datum: samoDatum,
				semestar: null,
				pocetak: tijelo.pocetak,
				kraj: tijelo.kraj
			}).then(function(termin) {
				db.Sala.findOne({ where: { naziv: tijelo.sala } }).then(
					function(sala) {
						db.Osoblje.findOne({
							where: { ime: imee[0], prezime: imee[1] }
						}).then(function(osoba) {
							db.Rezervacija.create({
								osoba: osoba.id,
								termin: termin.id,
								sala: sala.id
							}).then(function() {
								console.log(zauzecaCache);
								res.writeHead(200, {
									"Content-Type": "application/json"
								});
								res.write(JSON.stringify(zauzecaCache));
								res.end();
							});
						});
					}
				);
			});
		} else {
			let dan = datumZauzecaSale.getDay() - 1;
			if (dan < 0) dan = 6;
			let semestar =
				datumZauzecaSale.getMonth() >= 1 &&
				datumZauzecaSale.getMonth() <= 5
					? "ljetni"
					: "zimski";
			zauzecaCache.periodicna.push({
				dan: dan,
				semestar: semestar,
				pocetak: tijelo.pocetak,
				kraj: tijelo.kraj,
				naziv: tijelo.sala,
				predavac: tijelo.osoba
			});

			db.Termin.create({
				redovni: 1,
				dan: dan,
				datum: samoDatum,
				semestar: tijelo,
				semestar,
				pocetak: tijelo.pocetak,
				kraj: tijelo.kraj
			}).then(function(termin) {
				db.Sala.findOne({ where: { naziv: tijelo.sala } }).then(
					function(sala) {
						db.Osoblje.findOne({
							where: { ime: imee[0], prezime: imee[1] }
						}).then(function(osoba) {
							db.Rezervacija.create({
								osoba: osoba.id,
								termin: termin.id,
								sala: sala.id
							}).then(function() {
								console.log(zauzecaCache);
								res.writeHead(200, {
									"Content-Type": "application/json"
								});
								res.write(JSON.stringify(zauzecaCache));
								res.end();
							});
						});
					}
				);
			});
		}
	}
});

app.get("/slike", function(req, res) {
	fs.readdir(__dirname + "/slike", function(err, files) {
		let rez = [];
		let brojac = 0;
		for (let i = offset; i < files.length; i++) {
			rez.push(files[i]);
			if (++brojac == 3) break;
		}

		let objekat = {
			puteviSlika: rez
		};
		offset += 3;
		if (offset >= files.length) offset = 0;
		res.writeHead(200, { "Content-Type": "application/json" });
		res.write(JSON.stringify(objekat));
		res.end();
	});
});

app.get("/brojSlika", function(req, res) {
	fs.readdir(__dirname + "/slike", function(err, files) {
		res.writeHead(200, { "Content-Type": "application/json" });
		let objekat = {
			brojSlika: files.length
		};
		res.write(JSON.stringify(objekat));
		res.end();
	});
});

const db = require("./skripte/db.js");
db.sequelize.sync({ force: true }).then(function() {
	punjenjeTabela();
	console.log("Uspjesno kreiranje i popunjavanje tabela!");
});

app.get("/osoblje", function(req, res) {
	console.log("dohvati Osoblje");
	db.Osoblje.findAll().then(function(osobe) {
		var rez = [];
		for (let i = 0; i < osobe.length; i++) {
			rez.push(osobe[i].ime + " " + osobe[i].prezime);
		}
		res.send(rez);
		res.end();
	});
});


app.get("/zauzeca", function(req, res) {
	console.log("zauzeca");
	let zauzeca = {
		vanredna: [],
		periodicna: []
	};

	db.Rezervacija.findAll().then(function(rezervacije) {
		for (let i = 0; i < rezervacije.length; i++) {
			db.Termin.findOne({ where: { id: rezervacije[i].termin } }).then(
				function(termin) {
					db.Sala.findOne({
						where: { id: rezervacije[i].sala }
					}).then(function(sala) {
						db.Osoblje.findOne({
							where: { id: rezervacije[i].osoba }
						}).then(function(osoba) {
							if (termin.redovni == 1) {
								zauzeca.periodicna.push({
									dan: termin.dan,
									semestar: termin.semestar,
									pocetak: termin.pocetak,
									kraj: termin.kraj,
									naziv: sala.naziv,
									predavac: osoba.ime + " " + osoba.prezime
								});
							} else if (termin.redovni == 0) {
								zauzeca.vanredna.push({
									datum: termin.datum,
									pocetak: termin.pocetak,
									kraj: termin.kraj,
									naziv: sala.naziv,
									predavac: osoba.ime + " "+ osoba.prezime
								});
							}
							console.log(zauzeca.vanredna.length + zauzeca.periodicna.length);
							if ((zauzeca.vanredna.length + zauzeca.periodicna.length) == rezervacije.length) {
								zauzecaCache = zauzeca;
								res.send(zauzeca);
								res.end();
							}
						});
					});
				}
			);
		}
	});
});

function punjenjeTabela() {
	db.Osoblje.create({
		ime: "Neko",
		prezime: "Nekic",
		uloga: "profesor"
	}).then(function(o) {
		db.Osoblje.create({
			ime: "Drugi",
			prezime: "Neko",
			uloga: "asistent"
		}).then(function(o2) {
			db.Osoblje.create({
				ime: "Test",
				prezime: "Test",
				uloga: "asistent"
			}).then(function(o3) {
				db.Sala.create({
					naziv: "1-11",
					zaduzenaOsoba: 1
				}).then(function(s) {
					db.Sala.create({
						naziv: "1-15",
						zaduzenaOsoba: 2
					}).then(function(s2) {
						db.Termin.create({
							redovni: false,
							dan: null,
							datum: "01.01.2020",
							semestar: null,
							pocetak: "12:00",
							kraj: "13:00"
						}).then(function(t) {
							db.Termin.create({
								redovni: true,
								dan: 0,
								datum: null,
								semestar: "zimski",
								pocetak: "13:00",
								kraj: "14:00"
							}).then(function(t2) {
								db.Rezervacija.create({
									termin: 1,
									sala: 1,
									osoba: 1
								}).then(function(r) {
									db.Rezervacija.create({
										termin: 2,
										sala: 1,
										osoba: 3
									});
								});
							});
						});
					});
				});
			});
		});
	});
}

app.listen(8080);

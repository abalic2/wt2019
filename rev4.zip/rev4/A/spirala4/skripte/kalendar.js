let Mjesec = (function() {
	var trenutniMjesec = 0;
	var trenutniPoc = 2; //srijeda
	var dani = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
	var nazivi = [
		"Januar",
		"Februar",
		"Mart",
		"April",
		"Maj",
		"Juni",
		"Juli",
		"August",
		"Septembar",
		"Oktobar",
		"Novembar",
		"Decembar"
	];
	var trenutniKraj = (trenutniPoc + dani[trenutniMjesec] - 1) % 7;

	function sljedeciImpl() {
		if (trenutniMjesec == 11) return;
		trenutniMjesec++; //12
		trenutniPoc = (trenutniKraj + 1) % 7; //5 sub
		trenutniKraj = (trenutniPoc + dani[trenutniMjesec] - 1) % 7; //zadnji dan 1
	}

	function prethodniImpl() {
		if (trenutniMjesec == 0) return;
		trenutniMjesec--;
		trenutniKraj = trenutniPoc - 1;
		if (trenutniKraj == -1) trenutniKraj = 6;
		trenutniPoc -= dani[trenutniMjesec];
		trenutniPoc += (Math.floor(trenutniPoc / -7) + 1) * 7;
		trenutniPoc %= 7;
	}

	function getTrenutniMjesec() {
		return trenutniMjesec;
	}

	function getNazivMjseeca() {
		return nazivi[trenutniMjesec];
	}

	function getPocDan() {
		return trenutniPoc;
	}

	function getBrojDana() {
		return dani[trenutniMjesec];
	}

	function getTrenutniPoc() {
		return trenutniPoc;
	}

	function getTrenutniKraj() {
		return trenutniKraj;
	}

	return {
		prethodni: prethodniImpl,
		sljedeci: sljedeciImpl,
		trenutniMjesec: getTrenutniMjesec,
		nazivTrenutnog: getNazivMjseeca,
		pocDanMjeseca: getPocDan,
		brojDanaMjeseca: getBrojDana,
		trenutniPoc: getTrenutniPoc,
		trenutniKraj: getTrenutniKraj
	};
})();

let Kalendar = (function() {
	var zauzeca = [];

	//Test presjeka 2 vremenska opsega
	function presjekVremena(poc1, kraj1, poc2, kraj2) {
		let ukupMinutePoc1 =
			parseInt(poc1.substr(0, 2)) * 60 + parseInt(poc1.substr(3, 2));
		let ukupMinuteKraj1 =
			parseInt(kraj1.substr(0, 2)) * 60 + parseInt(kraj1.substr(3, 2));

		let ukupMinutePoc2 =
			parseInt(poc2.substr(0, 2)) * 60 + parseInt(poc2.substr(3, 2));
		let ukupMinuteKraj2 =
			parseInt(kraj2.substr(0, 2)) * 60 + parseInt(kraj2.substr(3, 2));
		//drugi pocinje prije nego sto prvi zavrsi i prvi pocinje prije nego sto drugi zavrsi
		//znaci da ova 2 vremena imaju presjekp
		let drugoSadrzanoUPrvom =
			ukupMinutePoc2 < ukupMinuteKraj1 &&
			ukupMinutePoc1 < ukupMinuteKraj2;
		return drugoSadrzanoUPrvom; //refaktoring
	}

	function validirajVrijeme(poc1, kraj1) {
		if (poc1.length < 5 || kraj1.length < 5) return false; //necemo predetaljno u validaciju
		let ukupMinutePoc1 =
			parseInt(poc1.substr(0, 2)) * 60 + parseInt(poc1.substr(3, 2));
		let ukupMinuteKraj1 =
			parseInt(kraj1.substr(0, 2)) * 60 + parseInt(kraj1.substr(3, 2));
		if (ukupMinutePoc1 >= ukupMinuteKraj1) return false;
		return true;
	}

	function oslobodiKalendar(kalendarRef) {
		let celije = kalendarRef.getElementsByClassName("broj");
		let i = 0;
		for (i = 0; i < celije.length; i++) {
			if (
				!celije[i].parentElement.parentElement.getElementsByClassName(
					"slobodna"
				).length == 1
			) {
				celije[i].parentElement.parentElement.getElementsByClassName(
					"zauzeta"
				)[0].className = "slobodna";
			}
		}
	}

	function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj) {
		if (
			mjesec != Mjesec.trenutniMjesec() ||
			!validirajVrijeme(pocetak, kraj) ||
			kalendarRef == null
		) {
			oslobodiKalendar(kalendarRef); //ako je neispravno, oboji sve u zeleno
			return; //validacija
		}

		let celije = kalendarRef.getElementsByClassName("broj");
		let i = 0,
			j = 0;
		for (i = 0; i < celije.length; i++) {
			for (j = 0; j < zauzeca.length; j++) {
				let el = zauzeca[j];
				let isteSale = el.naziv.toUpperCase() === sala.toUpperCase();
				let zauzetoVrijeme = presjekVremena(
					pocetak,
					kraj,
					el.pocetak,
					el.kraj
				);
				if (
					el.datum.getMonth() == mjesec &&
					isteSale &&
					zauzetoVrijeme &&
					el.datum.getDate() == i + 1
				) {
					if (
						!(
							celije[
								i
							].parentElement.parentElement.getElementsByClassName(
								"zauzeta"
							).length == 1
						)
					) {
						celije[
							i
						].parentElement.parentElement.getElementsByClassName(
							"slobodna"
						)[0].className = "zauzeta";
					}
					break;
				}
			}
			//ako nismo zauzeli ovaj termin, obojimo ga u zeleno ako je ostao od neke prethodne konfiguracije forme
			if (
				j == zauzeca.length &&
				!(
					celije[
						i
					].parentElement.parentElement.getElementsByClassName(
						"slobodna"
					).length == 1
				)
			) {
				celije[i].parentElement.parentElement.getElementsByClassName(
					"zauzeta"
				)[0].className = "slobodna";
			}
		}
	}

	function dajSvaPeriodicna(periodicna) {
		var rez = [];
		if (periodicna.semestar == "zimski") {
			//oktobar novembar decembar januar
			let prviDatum = new Date("1-1-2020"); //MM-DD-YYYY
			//posebno januar jer nema sad sljedece godine

			//pomjerimo na prvi validan dan i onda ostale
			while (prviDatum.getDay() != (periodicna.dan + 1) % 7) {
				prviDatum.setDate(prviDatum.getDate() + 1);
			}

			while (prviDatum.getMonth() == 0) {
				rez.push({
					datum: new Date(prviDatum),
					pocetak: periodicna.pocetak,
					kraj: periodicna.kraj,
					naziv: periodicna.naziv,
					predavac: periodicna.predavac
				});
				prviDatum.setDate(prviDatum.getDate() + 7);
			}

			//sad radimo ostale mjesece
			prviDatum = new Date("10-1-2020");
			while (prviDatum.getDay() != (periodicna.dan + 1) % 7) {
				prviDatum.setDate(prviDatum.getDate() + 1);
			}
			while (prviDatum.getMonth() >= 9 && prviDatum.getMonth() <= 11) {
				rez.push({
					datum: new Date(prviDatum),
					pocetak: periodicna.pocetak,
					kraj: periodicna.kraj,
					naziv: periodicna.naziv,
					predavac: periodicna.predavac
				});
				prviDatum.setDate(prviDatum.getDate() + 7);
			}
		} else if (periodicna.semestar == "ljetni") {
			//feb mart april maj juni
			prviDatum = new Date("2-1-2020");
			while (prviDatum.getDay() != (periodicna.dan + 1) % 7) {
				prviDatum.setDate(prviDatum.getDate() + 1);
			}
			while (prviDatum.getMonth() >= 1 && prviDatum.getMonth() <= 5) {
				rez.push({
					datum: new Date(prviDatum),
					pocetak: periodicna.pocetak,
					kraj: periodicna.kraj,
					naziv: periodicna.naziv,
					predavac: periodicna.predavac
				});
				prviDatum.setDate(prviDatum.getDate() + 7);
			}
		}
		return rez;
	}

	function ucitajPodatkeImpl(periodicna, vanredna) {
		//na sva vanredna dodaj jos periodicna kada ih pretvorimo u konkretne vanredne termine pomocu metode dajSvaPeriodicna
		let rez = [];

		vanredna.forEach(el => {
			let dan = Number(el.datum.substr(0, 2));
			let mjesec = Number(el.datum.substr(3, 2));
			mjesec--;
			let godina = Number(el.datum.substr(6, 4));
			rez.push({
				datum: new Date(godina, mjesec, dan),
				pocetak: el.pocetak,
				kraj: el.kraj,
				naziv: el.naziv,
				predavac: el.predavac
			});
			console.log(new Date(godina, mjesec, dan));
		});
		periodicna.forEach(el => {
			rez = rez.concat(dajSvaPeriodicna(el));
		});

		zauzeca = rez;
	}

	function iscrtajDan(klasa1, klasa2, tekst) {
		let klasaTabele = "brojTabela";
		if (klasa1 == "prazna") klasaTabele = "praznaTabela";
		return (
			'<table class="' +
			klasaTabele +
			'">\n<tr>\n<td class="' +
			klasa1 +
			'">' +
			tekst +
			'</td>\n</tr>\n<tr>\n<td class="' +
			klasa2 +
			'"></td>\n</tr>\n</table>'
		);
	}
	function iscrtajKalendarImpl(kalendarRef, mjesec) {
		if (mjesec < 0 || mjesec > 11) return;
		//azuriramo trenutniMjesec na zadanu vrijednost
		while (mjesec > Mjesec.trenutniMjesec()) {
			Mjesec.sljedeci();
		}
		while (mjesec < Mjesec.trenutniMjesec()) {
			Mjesec.prethodni();
		}
		document.getElementById(
			"nazivMjeseca"
		).innerHTML = Mjesec.nazivTrenutnog();
		//iscrtamo prvu sedmicu pazeci na prazne
		let prvaSed = document.getElementsByClassName("prvaSedmica")[0];
		prvaSed.innerHTML = "";
		let prazne = Mjesec.pocDanMjeseca() - 1;
		while (prazne >= 0) {
			prvaSed.innerHTML += iscrtajDan("prazna", "prazna", "");
			prazne--;
		}
		let punePrve = 6 - Mjesec.pocDanMjeseca();
		let gornja = Mjesec.brojDanaMjeseca();
		let brojac = 1;

		while (punePrve >= 0) {
			prvaSed.innerHTML += iscrtajDan("broj", "slobodna", brojac++);
			punePrve--;
		}
		let ostatakMj = document.getElementsByClassName("ostatakMj")[0];
		ostatakMj.innerHTML = "";
		while (brojac <= gornja) {
			ostatakMj.innerHTML += iscrtajDan("broj", "slobodna", brojac++);
		}
	}

	function postojiZauzeceImpl(pocetak, kraj, sala, datum, periodicna) {
		datum.setHours(0, 0, 0, 0);
		if (periodicna) {
			let semestar =
				datum.getMonth() >= 1 && datum.getMonth() <= 5
					? "ljetni"
					: "zimski";
			let dan = datum.getDay() - 1;
			if (dan < 0) dan = 6;
			let zauzecePeriodicno = {
				dan: dan,
				semestar: semestar,
				pocetak: pocetak,
				kraj: kraj,
				naziv: sala,
				predavac: "Huga Buga"
			};
			/* Pretvorimo periodicno u sva vanredna i provjerimo hoce li ijedno vrijeme kaciti */
			let nizVanrednih = dajSvaPeriodicna(zauzecePeriodicno);

			for (let i = 0; i < nizVanrednih.length; i++) {
				let el = nizVanrednih[i];
				for (let j = 0; j < zauzeca.length; j++) {
					let el2 = zauzeca[j];
					el.datum.setHours(0, 0, 0, 0);
					el2.datum.setHours(0, 0, 0, 0);
					if (
						presjekVremena(
							el.pocetak,
							el.kraj,
							el2.pocetak,
							el2.kraj
						) &&
						el.datum.getTime() == el2.datum.getTime() &&
						el.naziv == el2.naziv
					)
						return 1;
				}
			}
		} else {
			for (let i = 0; i < zauzeca.length; i++) {
				zauzeca[i].datum.setHours(0, 0, 0, 0);
				if (
					presjekVremena(
						zauzeca[i].pocetak,
						zauzeca[i].kraj,
						pocetak,
						kraj
					) &&
					zauzeca[i].datum.getTime() == datum.getTime() &&
					zauzeca[i].naziv == sala
				)
					return 1;
			}
			zauzeca.forEach(function(el) {});
		}

		return 0;
	}

	function ispisiKoJeZauzeoImpl(pocetak, kraj, datum, sala) {
		console.log("ime sale " + sala);
		let datumObj = new Date(
			Number(datum.substr(6, 4)),
			Number(datum.substr(3, 2)) - 1,
			Number(datum.substr(0, 2))
		);
		let svaZauzeca = zauzeca;
		svaZauzeca = svaZauzeca.filter(function(zauzece) {
			console.log(zauzece);
			let istiDatumi =
				zauzece.datum.getDate() == datumObj.getDate() &&
				zauzece.datum.getMonth() == datumObj.getMonth() &&
				zauzece.datum.getYear() == datumObj.getYear();
			let istaVremena = presjekVremena(zauzece.pocetak,zauzece.kraj,pocetak,kraj);
			let istaSala = zauzece.naziv==sala;
			console.log("DATUMI " + istiDatumi + " VREMENA " + istaVremena + " SALE " + istaSala);
			console.log("UKUPNO " + (istiDatumi &&istaVremena&&istaSala));
			return (istiDatumi && istaVremena && istaSala);
		});
		alert("Nije moguće rezervisati salu "+sala+" za navedeni datum: "+datum+" i termin od " + pocetak + " do " + kraj+"!Salu je vec rezervisala osoba: "+svaZauzeca[0].predavac);
	}

	return {
		obojiZauzeca: obojiZauzecaImpl,
		ucitajPodatke: ucitajPodatkeImpl,
		iscrtajKalendar: iscrtajKalendarImpl,
		dajSvaPeriodicna: dajSvaPeriodicna,
		postojiZauzece: postojiZauzeceImpl,
		ispisiKoJeZauzeo:ispisiKoJeZauzeoImpl,
		pretvoriPeriodicnoUVanredna:dajSvaPeriodicna
	};
})();

let assert = chai.assert;
let kalendar = document.getElementsByClassName("kalendar")[0];

//UPUTA ZA TESTIRANJE:
//1. ugasite server ako vam je trenutno upaljen
//2. pokrenite server
//3. ukucajte http://localhost:8080/testoviSpirala4.html
//4. Ne pokrecite opet testove bez da ugasite i ponovno pokrenete server
// jer je promijenjeno stanje baze i padat ce vecina

//NAPOMENA: imajte u vidu da baza (bas rijetko, ali desi se) zakaze ili "uspava", pa u tim slučajevima ponovite postupak opisan gore.
//Desavalo se i svim kolegama s kojima sam pricao o spirali, iako iznimno iznimno rijetko (najcesce pri porketeanju servera
//ne pronadje neku od tabela, dok ponovnim pokretanjem bez ikakvih promjena radi gotovo svaki iduci put )

//DODAVANJEM CALLBACK-A done kao parametar funkciji testa, funkcija testa čeka da se pozove funkcija done i tek onda zavrsava test
// i to je podrska za asinhrone dogadjaje

//takodjer, ako se ne pozove done() ili se pozove vise puta, test pada, tako da je jedini način da prođe test da se pozove tačno jednomo
//sto je u testovima upravo i planirano da bi test prosao

//takodjer, kada pozovemo callback done sa greskom, test pada. To je koristeno umjesto asserta ovdje, da bi test pao
//ako se ne podduara ono sto se testira samim testom

//U LOG-u ce pisati da "server interal error" kod onih testova kada je svjesno izazvano to ponasanje
//time sto se pokusa zauzeti vec zauzeti termin, pa je u tom slučaju server vraćao kod 500 (pogledati index.js) 

describe("Server testovi", function() {
	it("Get osoblje. Inicijalno bi trebalo da imaju 3 osobe kada kreiramo tabelu", function(done) {
		let ajax2 = new XMLHttpRequest();
		console.log("Osoblje");
		ajax2.onreadystatechange = function() {
			if (ajax2.readyState == 4 && ajax2.status == 200) {
				let osobe = JSON.parse(ajax2.response);
				if (osobe.length == 3) {
					console.log("Prosao prvi test");
					done();
				} else {
					console.log("Pao prvi test");
					done(
						new Error(
							"Broj osoba treba biti 3 a on je " + osobe.length
						)
					);
				}
			}
		};
		ajax2.open("GET", "http://localhost:8080/osoblje", true);
		ajax2.send();
	});

	it("Dohvatanje svih zauzeca. Inicijalno bi trebalo biti 1 vanredno", function(done) {
		let ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) {
				let zauzeca = JSON.parse(ajax.responseText);
				if (zauzeca.vanredna.length == 1) {
					console.log("Prosao drugi test");
					done();
				} else {
					console.log("Pao drugi test");
					done(
						new Error(
							"Inicijalno treba biti 1 vanredno zauzece a ima ih " +
								zauzeca.vanredna.length
						)
					);
				}
			}
		};
		ajax.open("GET", "http://localhost:8080/zauzeca", true);
		ajax.send();
	});

	it("Dohvatanje svih zauzeca. Inicijalno bi trebalo biti 1 periodicno", function(done) {
		let ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) {
				let zauzeca = JSON.parse(ajax.responseText);
				if (zauzeca.periodicna.length == 1) {
					console.log("Prosao treci test");
					done();
				} else {
					console.log("Pao treci test");
					done(
						new Error(
							"Inicijalno treba biti 1 periodicno zauzece a ima ih " +
								zauzeca.periodicna.length
						)
					);
				}
			}
		};
		ajax.open("GET", "http://localhost:8080/zauzeca", true);
		ajax.send();
	});

	it("Dodavanje vanrednog zauzeca. Nakon toga broj vanrednih treba biti 2.", function(done) {
		let ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) {
				let ajax2 = new XMLHttpRequest();
				ajax2.onreadystatechange = function() {
					if (ajax2.readyState == 4 && ajax2.status == 200) {
						let zauzeca = JSON.parse(ajax2.responseText);
						assert.equal(
							zauzeca.vanredna.length,
							2,
							"Moraju biti 2 vanredna zauzece"
						);
						done();
					}
				};
				ajax2.open("GET", "http://localhost:8080/zauzeca", true);
				ajax2.send();
			}
		};
		let zauzece = {
			pocetak: "08:30",
			kraj: "10:00",
			sala: "1-11",
			datum: "01.02.2020",
			periodicna: false,
			osoba: "Neko Nekic"
		};
		ajax.open("POST", "http://localhost:8080/rezervacije", true);
		ajax.setRequestHeader("Content-Type", "application/json");
		ajax.send(JSON.stringify(zauzece));
	});

	it("Dodavanje redovnog zauzeca. Nakon toga broj redovnih treba biti 2.", function(done) {
		let ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) {
				let ajax2 = new XMLHttpRequest();
				ajax2.onreadystatechange = function() {
					if (ajax2.readyState == 4 && ajax2.status == 200) {
						let zauzeca = JSON.parse(ajax2.responseText);
						if (zauzeca.vanredna.length == 2) {
							console.log("Prosao peti test");
							done();
						} else {
							console.log("Pao peti test");
							done(
								new Error(
									"Moraju biti 2 vanredna zauzece a ima ih " +
										zauzeca.vanredna.length
								)
							);
						}
					}
				};
				ajax2.open("GET", "http://localhost:8080/zauzeca", true);
				ajax2.send();
			}
		};
		let zauzece = {
			pocetak: "08:30",
			kraj: "10:00",
			sala: "1-11",
			datum: "05.02.2020",
			periodicna: true,
			osoba: "Neko Nekic"
		};
		ajax.open("POST", "http://localhost:8080/rezervacije", true);
		ajax.setRequestHeader("Content-Type", "application/json");
		ajax.send(JSON.stringify(zauzece));
	});

	it("Dohvatanje svih sala. Sala treba biti inicijalno 2 (1-11 i 1-15)", function(done) {
		let ajax2 = new XMLHttpRequest();
		ajax2.onreadystatechange = function() {
			if (ajax2.readyState == 4 && ajax2.status == 200) {
				let sale = JSON.parse(ajax2.responseText);
				if (sale.length == 2) {
					console.log("Prosao sesti test");
					done();
				} else {
					console.log("Pao sesti test");
					done(
						new Error(
							"sala treba biti inicijalno 2 a ima ih " +
								sale.length
						)
					);
				}
			}
		};
		ajax2.open("GET", "http://localhost:8080/sale", true);
		ajax2.send();
	});

	it("Kreiranje nove rezervacije. Rezervisemo zauzet termin vanrednim zauzecem", function(done) {
		let ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 500) {
				console.log("Prosao sedmi test");
				done();
			} else if (ajax.readyState == 4 && ajax.status != 500) {
				console.log("Pao sedmi test");
				done(
					new Error(
						"Rezervacija bi trebala biti odbijeno jer je vec zauzeto"
					)
				);
			}
		};
		let zauzece = {
			pocetak: "08:30",
			kraj: "22:00",
			sala: "1-11",
			datum: "01.01.2020",
			periodicna: false,
			osoba: "Neko Nekic"
		};
		ajax.open("POST", "http://localhost:8080/rezervacije", true);
		ajax.setRequestHeader("Content-Type", "application/json");
		ajax.send(JSON.stringify(zauzece));
	});

	it("Kreiranje nove rezervacije. Rezervisemo slobodan termin periodicno koji se ipak preklapa sa nekim vanrednim zauzecem ", function(done) {
		let ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 500) {
				console.log("Prosao osmi test");
				done();
			} else if (ajax.readyState == 4 && ajax.status != 500) {
				console.log("Pao osmi test");
				done(
					new Error(
						"Rezervacija bi trebala biti odbijeno jer je vec zauzeto"
					)
				);
			}
		};
		let zauzece = {
			pocetak: "08:30",
			kraj: "22:00",
			sala: "1-11",
			datum: "08.01.2020",
			periodicna: true,
			osoba: "Neko Nekic"
		};
		ajax.open("POST", "http://localhost:8080/rezervacije", true);
		ajax.setRequestHeader("Content-Type", "application/json");
		ajax.send(JSON.stringify(zauzece));
	});

	it("Kreiranje nove rezervacije. Rezervisemo termin na drugo ime u odnosu na termin koji se preklapa. Server bi opet trebao da odbije rezervaciju", function(done) {
		let ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 500) {
				console.log("Prosao deveti test");
				done();
			} else if (ajax.readyState == 4 && ajax.status != 500) {
				console.log("Pao deveti test");
				done(
					new Error(
						"Rezervacija bi trebala biti odbijeno jer je vec zauzeto iako od druge osobe"
					)
				);
			}
		};
		let zauzece = {
			pocetak: "08:30",
			kraj: "22:00",
			sala: "1-11",
			datum: "08.01.2020",
			periodicna: true,
			osoba: "Drugi Neko"
		};
		ajax.open("POST", "http://localhost:8080/rezervacije", true);
		ajax.setRequestHeader("Content-Type", "application/json");
		ajax.send(JSON.stringify(zauzece));
	});

	it("Dodavanje 1 periodicne rezervacije u ljetnom semestru na isti dan kad vec ima u zimskom (ponedjeljak). Trebao bi uspjesno dodati ", function(done) {
		let ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) {
				console.log("Prosao deseti test");
				done();
			} 
			
			else if (ajax.readyState == 4 && ajax.status != 200) {
				console.log("Pao deseti test");
				done(
					new Error(
						"Greska.Server je odbio dodati rezervaciju iako je u ljetnom semestru"
					)
				);
			}
		};
		let zauzece = {
			pocetak: "08:30",
			kraj: "22:00",
			sala: "1-11",
			datum: "03.02.2020",
			periodicna: true,
			osoba: "Test Test"
		};
		ajax.open("POST", "http://localhost:8080/rezervacije", true);
		ajax.setRequestHeader("Content-Type", "application/json");
		ajax.send(JSON.stringify(zauzece));
	});	
});

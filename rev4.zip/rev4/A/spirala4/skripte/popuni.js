function popuniOsobljeZauzeca(){
    Pozivi.dajOsoblje();
    //kada se pozovu 2 asinhrone metode jedna za drugom, nastane problem
    Pozivi.dajZauzeca();
    Pozivi.dajSale();
}

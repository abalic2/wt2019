let Pozivi = (function() {
	var nizSlika = [];
	var maxStranica = 0;
	var indeks = 0;
	let ajax = new XMLHttpRequest();

	function dajZauzecaImpl() {
		console.log("DAJ ZAUZECA");
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) {
				console.log(ajax.responseText);
				let zauzeca = JSON.parse(ajax.responseText);
				Kalendar.ucitajPodatke(zauzeca.periodicna, zauzeca.vanredna);
			}
		};
		ajax.open("GET", "http://localhost:8080/zauzeca", true);
		ajax.send();
	}

	function pretvoriUVanredna(vanredna, periodicna) {
		let rez = [];

		vanredna.forEach(el => {
			let dan = Number(el.datum.substr(0, 2));
			let mjesec = Number(el.datum.substr(3, 2));
			mjesec--;
			let godina = Number(el.datum.substr(6, 4));
			rez.push({
				datum: new Date(godina, mjesec, dan),
				pocetak: el.pocetak,
				kraj: el.kraj,
				naziv: el.naziv,
				predavac: el.predavac
			});
			console.log(new Date(godina, mjesec, dan));
		});
		periodicna.forEach(el => {
			rez = rez.concat(Kalendar.pretvoriPeriodicnoUVanredna(el));
		});

		return rez;
	}

	function vrijemeIzmedju(poc1, kraj1,datum) {
		let trenutniDatum = new Date();
		if(datum.getDate()!=trenutniDatum.getDate() || datum.getMonth() !=trenutniDatum.getMonth() || datum.getYear()!=trenutniDatum.getYear()) return false;
		let vrijeme =
			trenutniDatum.getHours() * 60 + trenutniDatum.getMinutes();
		let ukupMinutePoc1 =
			parseInt(poc1.substr(0, 2)) * 60 + parseInt(poc1.substr(3, 2));
		let ukupMinuteKraj1 =
			parseInt(kraj1.substr(0, 2)) * 60 + parseInt(kraj1.substr(3, 2));
		return ukupMinutePoc1 <= vrijeme && vrijeme <= ukupMinuteKraj1;
	}

	function dajSaleOsoba(zauzeca) {
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) {
				let tabelaOsoba = document.getElementById("tabelaOsoba");
				tabelaOsoba.innerHTML = `<tr><th class="osobeHeader">Osoblje</th><th class ="osobeHeader">Trenutna lokacija</th></tr>`;
				let osobe = JSON.parse(ajax.responseText);
				for (let i = 0; i < osobe.length; i++) {
					let j=0;
					for (; j < zauzeca.length; j++) {
						let istiPredavac =
							zauzeca[j].predavac ==
							osobe[i];
						let istoVrijeme = vrijemeIzmedju(
							zauzeca[j].pocetak,
							zauzeca[j].kraj,
							zauzeca[j].datum
						);
						if (istiPredavac && istoVrijeme) {
							tabelaOsoba.innerHTML +=
								`<tr> <td> ` +
								osobe[i]+
								`</td><td>` + zauzeca[j].naziv+ ` </td> </tr>`;
								break;
						}
					}
					if(j==zauzeca.length){
						tabelaOsoba.innerHTML +=
						`<tr> <td> ` +
						osobe[i] +
						`</td><td>u kancelariji </td> </tr>`;
					}
				}
			}
		};
		ajax.open("GET", "http://localhost:8080/osoblje", true);
		ajax.send();
	}

	function dajLokacijeOsobljaImpl() {
		console.log("lokacija osoblja pozvano");
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) {
				console.log(ajax.responseText);
				let zauzeca = JSON.parse(ajax.responseText);
				dajSaleOsoba(
					pretvoriUVanredna(zauzeca.vanredna, zauzeca.periodicna)
				);
			}
		};
		ajax.open("GET", "http://localhost:8080/zauzeca", true);
		ajax.send();
	}

	function zauzmiSaluImpl(
		kalendarRef,
		pocetak,
		kraj,
		sala,
		datum,
		periodicna,
		osoba
	) {
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) {
				let zauzeca = JSON.parse(ajax.responseText);
				console.log(zauzeca);
				Kalendar.ucitajPodatke(zauzeca.periodicna, zauzeca.vanredna);
				Kalendar.obojiZauzeca(
					kalendarRef,
					Mjesec.trenutniMjesec(),
					sala,
					pocetak,
					kraj
				);
			} else if (ajax.readyState == 4 && ajax.status == 500) {
				alert(ajax.response);
			}
		};
		let zauzece = {
			pocetak,
			kraj,
			sala,
			datum,
			periodicna,
			osoba
		};
		console.log("Datum drugi gresni + " + datum);
		ajax.open("POST", "http://localhost:8080/rezervacije", true);
		ajax.setRequestHeader("Content-Type", "application/json");
		ajax.send(JSON.stringify(zauzece));
	}

	function dajOsobljeImpl() {
		let ajax2 = new XMLHttpRequest();
		console.log("Osoblje");
		ajax2.onreadystatechange = function() {
			if (ajax2.readyState == 4 && ajax2.status == 200) {
				let osobe = JSON.parse(ajax2.responseText);
				let osobSelect = document.getElementById("osoblje");
				for (let i = 0; i < osobe.length; i++) {
					let osoba = document.createElement("option");
					osoba.value = osobe[i];
					osoba.text = osobe[i];
					osobSelect.add(osoba);
				}
			}
		};
		ajax2.open("GET", "http://localhost:8080/osoblje", true);
		ajax2.send();
	}

	function dajSaleImpl() {
		console.log("Sale");
		let ajax2 = new XMLHttpRequest();
		ajax2.onreadystatechange = function() {
			if (ajax2.readyState == 4 && ajax2.status == 200) {
				let sale = JSON.parse(ajax2.responseText);
				let saleSelect = document.getElementsByName("sale")[0];
				for (let i = 0; i < sale.length; i++) {
					let sala = document.createElement("option");
					sala.value = sale[i];
					sala.text = sale[i];
					saleSelect.add(sala);
				}
			}
		};
		ajax2.open("GET", "http://localhost:8080/sale", true);
		ajax2.send();
	}

	function dajSlikeSljedeciImpl() {
		if (indeks == maxStranica) return;
		indeks++;
		if (indeks <= nizSlika.length) {
			galerija.innerHTML = nizSlika[indeks - 1];
		} else {
			ajax.onreadystatechange = function() {
				if (ajax.readyState == 4 && ajax.status == 200) {
					let niz = JSON.parse(ajax.responseText).puteviSlika;
					galerija.innerHTML = "";
					let htmlKod = "";
					for (let i = 0; i < niz.length; i++) {
						htmlKod +=
							'<img src="../slike/' +
							niz[i] +
							'" class = "slikaGalerije" alt = "slika ' +
							(i + 1) +
							'"/>';
					}

					nizSlika.push(htmlKod);
					galerija.innerHTML = htmlKod;
				}
			};
			console.log("Saljem zahtjev za slike");
			ajax.open("GET", "http://localhost:8080/slike", true);
			ajax.send();
		}
	}

	function dajSlikePrethodniImpl() {
		if (indeks == 1) return;
		indeks--;
		galerija.innerHTML = nizSlika[indeks - 1];
	}

	function pocetneSlikeImpl() {
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) {
				let broj = JSON.parse(ajax.responseText);
				maxSlika = broj.brojSlika;
				maxStranica = Math.floor(maxSlika / 3);
				if (maxSlika % 3 != 0) maxStranica++;
				dajSlikeSljedeciImpl();
			}
		};
		ajax.open("GET", "http://localhost:8080/brojSlika", true);
		ajax.send();
	}
	return {
		dajZauzeca: dajZauzecaImpl,
		zauzmiSalu: zauzmiSaluImpl,
		dajSlikeSljedeci: dajSlikeSljedeciImpl,
		dajSlikePrethodni: dajSlikePrethodniImpl,
		pocetneSlike: pocetneSlikeImpl,
		dajOsoblje: dajOsobljeImpl,
		dajSale: dajSaleImpl,
		dajLokacijeOsoblja: dajLokacijeOsobljaImpl
	};
})();

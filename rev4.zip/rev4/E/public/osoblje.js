Pozivi.ucitajZauzeca();
setInterval(Pozivi.ucitajZauzeca, 30000);
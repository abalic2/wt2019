function saleFunction() {
  Pozivi.salePoziv();
}
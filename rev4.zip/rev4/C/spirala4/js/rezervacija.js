window.onload = function () {
	rezervacijaFunction();
	addConfirmation();
	
	/*var periodicna = {dan: 3, semestar : "zimski", pocetak: "13:59", kraj:"14:59", naziv: "VA-01", predavac:"Ime Prezi"};
    var vanredna = {datum:"11.12.2019", pocetak:"15:00", kraj:"17:00", naziv: "MA", predavac:"Imenko Prezimenko"};
	var trenutni = new Date();
    mjesec = trenutni.getMonth();
	var godina = trenutni.getYear();
	var dan = periodicna.dan;
	Kalendar.ucitajPodatke(periodicna,vanredna);
	Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), mjesec, periodicna.sala, periodicna.pocetak, periodicna.kraj);*/
}

function todonext(){
	if(mjesec<=10){
		rezervacijaFunction();
		addConfirmation();
		mjesec = mjesec+1;
		Kalendar.iscrtajKalendar(kalendarRef, mjesec);
		//global_periodicna.dan = 1;
		Kalendar.ucitajPodatke(global_periodicna,global_vanredna);
		Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), mjesec, global_periodicna.sala, global_periodicna.pocetak, global_periodicna.kraj);	
		Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), mjesec, global_vanredna.naziv, global_vanredna.pocetak, global_vanredna.kraj);	
	}
}

function todobefore(){
	if(mjesec>0){
		rezervacijaFunction();
		addConfirmation();
		mjesec = mjesec-1;
		Kalendar.iscrtajKalendar(kalendarRef, mjesec);	
		//global_periodicna.dan = 3;
		Kalendar.ucitajPodatke(global_periodicna,global_vanredna);
		Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), mjesec, global_periodicna.sala, global_periodicna.pocetak, global_periodicna.kraj);
		Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), mjesec, global_vanredna.naziv, global_vanredna.pocetak, global_vanredna.kraj);	
	}
}
function todo(){
	var periodicna = {};
	var vanredna = {};
	periodicna.naziv = document.getElementsByName("lista")[0].value;
	vanredna.naziv = document.getElementsByName("lista")[0].value;
	periodicna.pocetak = document.getElementsByName("pocetak")[0].value;
	periodicna.kraj = document.getElementsByName("kraj")[0].value;
	vanredna.pocetak = document.getElementsByName("pocetak")[0].value;
	vanredna.kraj = document.getElementsByName("kraj")[0].value;
	vanredna.datum = "17.10.2019";
	//periodicna.mjesec = 12;
	Kalendar.ucitajPodatke(periodicna,vanredna);
	Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), periodicna.mjesec, periodicna.sala, periodicna.pocetak, periodicna.kraj);	
	Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), mjesec, vanredna.naziv, vanredna.pocetak, vanredna.kraj);
}

function rezervacijaFunction() {
  Pozivi.rezervacijaPoziv();
}

/* Funkcija za dodavanje EventListenera nad danima NOTE: Ruznije rjesenje bi bilo da smo na html-u dodali onclick i pozivali funkciju confirmationFunction*/
function addConfirmation(){
	var classname = document.getElementsByClassName("dan");

	for (var i = 0; i < classname.length; i++) {
		classname[i].addEventListener('click', confirmationFunction, false);
	}	
}
function confirmationFunction() {

	// imena mjeseci i dana u sedmici 
	var mjesecImena = ["Januar","Februar","Mart","April","Maj","Juni","Juli","August","Septembar","Oktobar","Novembar", "Decembar"];
	// naziv mjeseca sa UI koji cemo koristiti prilikom ispisa
	var mjesec = document.getElementsByTagName("h2")[0].innerHTML;
	var brMjesec = 0;
	for(var i =0; i<mjesecImena.length; i++)
	{
		if(mjesecImena[i]==mjesec)
		{
			brMjesec = i+1;
		}
	}
	if (brMjesec==9 || brMjesec==10 || brMjesec==11 || brMjesec==0)
	{
		var semestar = "zimski";
	} else {
		var semestar = "ljetni";
	}
	var checkbox = document.getElementById("checkbox").checked;
	
	var trenutni = new Date();
	var godina = 2020;
	var predavac = document.getElementById('osoblje').value;
	var pocetak = document.getElementsByTagName("input")[1].value;
	var kraj = document.getElementsByTagName("input")[2].value;
	var listaSala = document.getElementById("sala");
	var sala = listaSala.options[listaSala.selectedIndex].text;
	
	var r = confirm("Da li želite da rezervišete ovaj termin?");
	if (r == true) {
		if(checkbox==true){
			var periodicna = [dan, semestar, pocetak, kraj, sala, predavac];
			Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), mjesec, periodicna[sala], periodicna[pocetak], periodicna[kraj]);	
		}
		else {
			var vanredna = [datum, pocetak, kraj, sala, predavac];
			Kalendar.obojiZauzeca(document.getElementsByClassName("kalendar_mjesec"), mjesec, vanredna[sala], vanredna[pocetak], vanredna[kraj]);
		}
	} 
	else {
		alert("“Nije moguće rezervisati salu NAZIV za navedeni datum DD/MM/YYYY i termin od HH:MM do HH:MM!”");
	}
}
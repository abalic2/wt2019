const Sequelize = require("sequelize");
const sequelize = new Sequelize("dbwt19","root","root",{host:"127.0.0.1",dialect:"mysql",logging:false});
const db={};

db.Sequelize = Sequelize;  
db.sequelize = sequelize;

//import modela
db.osoblje = sequelize.import(__dirname+'/osoblje.js');
db.rezervacija = sequelize.import(__dirname+'/rezervacije.js');
db.termin = sequelize.import(__dirname+'/termin.js');
db.sala = sequelize.import(__dirname+'/sala.js');

//relacije
// Veza 1-n - Osoblje - jedan na više - Rezervacija
db.osoblje.hasMany(db.rezervacija,{foreignKey:'osoba'});

// Veza 1-1 - Rezervacija - jedan na jedan - Termin
db.rezervacija.belongsTo(db.termin,{foreignKey:'termin'});

// Veza 1-n - Rezervacija - više na jedan - Sala
db.sala.hasMany(db.rezervacija,{foreignKey:'sala'});

// Veza 1-1 - - Sala - jedan na jedan - Osoblje
db.sala.belongsTo(db.osoblje,{foreignKey:'zaduzenaOsoba'});

// Veza 1-1 - Rezervacija - jedan na jedan - Osoblje
db.rezervacija.belongsTo(db.osoblje,{foreignKey:'osoba'});

// Veza 1-1 - Rezervacija - jedan na jedan - Osoblje
db.rezervacija.belongsTo(db.sala,{foreignKey:'sala'});

module.exports=db;
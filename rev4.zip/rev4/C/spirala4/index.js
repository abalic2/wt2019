const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const arraySlike = require('./slike.json');
const arrayZauzeca = require('./zauzeca.json');
const Sequelize = require('sequelize');
const baza = require('./db.js');


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use("/css", express.static('./css/'));
app.use("/js", express.static('./js/'));
app.get('/',function(req,res){
    res.sendFile(__dirname + '/html/pocetna.html');
});
app.get('/pocetna.html',function(req,res)
{
    res.sendFile(__dirname + '/html/pocetna.html');
});

app.get('/sale.html',function(req,res)
{
    res.sendFile(__dirname + '/html/sale.html');
});

app.get('/unos.html',function(req,res)
{
    res.sendFile(__dirname + '/html/unos.html');
});

app.get('/rezervacija.html',function(req,res)
{
    res.sendFile(__dirname + '/html/rezervacija.html');
});

app.get('/osobe.html',function(req,res)
{
    res.sendFile(__dirname + '/html/osobe.html');
});

// Na serveru treba biti definisana ruta GET /osoblje koja vraća svo osoblje.
app.route('/osoblje') 
    .get(function(req, res) {
        baza.osoblje.findAll().then(function(osoblje) {
          var osobe = [];
			var arr = osoblje;
			for (var i=0; i<arr.length; i++) {
				osobe.push(arr[i].ime + " " + arr[i].prezime);			
			}
			res.status(200).send(osobe);
        });
});

app.route('/sala') 
    .get(function(req, res) {
        baza.sala.findAll().then(function(sala) {
          var sale = [];
			var arr = sala;
			for (var i=0; i<arr.length; i++) {
				sale.push(sala[i].naziv);			
			}
			res.status(200).send(sale);
        });
});

app.get('/temp.js',function(req,res)
{
    res.sendFile(__dirname + '/temp.js');
});

app.get('/slike.json',function(req,res)
{
	var number = 3;
	var offset = parseInt(req.query.offset);
	var arr = [];
	//var array = ["css/photo1.jpg","css/photo2.jpg","css/photo3.jpg","css/photo4.jpg","css/photo5.jpg","css/photo6.jpg","css/photo7.jpg","css/photo8.jpg","css/photo9.jpg","css/photo10.jpg"];
    for (var i=0; i<arraySlike.length; i++) {
		if (i>=offset && i<(number+offset) ) {
				arr.push(arraySlike[i]);
			}			
	}
	res.json(arr);
});

app.route('/zauzeca') 
    .get(function(req, res) {
        baza.rezervacija.findAll().then(function(rezervacija) {
          var zauzeca = [];
			var arr = rezervacija;
			for (var i=0; i<arr.length; i++) {
				baza.sala.findOne({ where: { id: arr[i].sala } }).then(function(sala) { console.log(sala.naziv);});
				baza.osoblje.findOne({ where: { id: arr[i].osoba } }).then(function(osoblje) { console.log(osoblje.ime + " " + osoblje.prezime);});
		
				//zauzeca.push(sale.naziv);
				//zauzeca.push(osoba.ime + " " + osoba.prezime);					
			}
			res.status(200).send(rezervacija);
        });
});

app.post('/zauzeca', function (req, res) {
  var kreirajRezervaciju = {
    termin: req.baza.termin,
    sala: req.baza.sala,
    osoba: req.baza.osoba,
   }
   connection.query('INSERT INTO baza.rezervacija SET ?', kreirajRezervaciju, function (err, resp) {
     if (err) throw err;
     // if there are no errors send an OK message.
     res.send('Succes!');
   });
 });

app.route('/osobe') 
    .get(function(req, res) {
        baza.rezervacija.findAll({include: [{model: baza.osoblje}, {model: baza.sala}]}).then(function(rezervacija) {
          var zauzeca = [];
		  var zsale = [];
			var arr = rezervacija;
			for(var i=0; i<arr.length();i++){
				zauzeca.push(arr[i].Osoblje.ime + " " + arr[i].Osoblje.prezime); 
			}
			res.json(arr);
        });
});

app.get('/zauzeca.json',function(req,res)
{
	res.json(arrayZauzeca);
});

app.listen(8080);

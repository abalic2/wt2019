const db = require('./db.js')
db.sequelize.sync({force:true}).then(function(){
    inicializacija().then(function(){
        console.log("Gotovo kreiranje tabela i ubacivanje pocetnih podataka!");
        process.exit();
    });
});
function inicializacija(){
    var osobljeListaPromisea=[];
    var salaListaPromisea=[];
    var terminListaPromisea=[];
	var rezervacijaListaPromisea=[];
    return new Promise(function(resolve,reject){
    osobljeListaPromisea.push(db.osoblje.create({ime:'Neko',prezime:'Nekic',uloga:'profesor'}));
	osobljeListaPromisea.push(db.osoblje.create({ime:'Drugi',prezime:'Neko',uloga:'asistent'}));
	osobljeListaPromisea.push(db.osoblje.create({ime:'Test',prezime:'Test',uloga:'asistent'}));	
	terminListaPromisea.push(db.termin.create({redovni:false,datum:'2020-01-01',pocetak:"12:00",kraj:"13:00"}));
	terminListaPromisea.push(db.termin.create({redovni:true,dan:0,semestar:'zimski',pocetak:"13:00",kraj:"14:00"}));
    Promise.all(osobljeListaPromisea).then(function(osoblje){
		var osoblje1 = osoblje.filter(function(o){return o.id==1})[0];
        var osoblje2 = osoblje.filter(function(o){return o.id==2})[0];
		var osoblje3 = osoblje.filter(function(o){return o.id==3})[0];
		//console.log([osoblje1]);
        
		salaListaPromisea.push(
            db.sala.create({naziv:'1-15', zaduzenaOsoba:osoblje2.id}).then(function(a){	
				//console.log([osoblje1]);
                return new Promise(function(resolve,reject){resolve(a);});
            })
        );
	
		salaListaPromisea.push(
            db.sala.create({naziv:'1-11', zaduzenaOsoba:osoblje1.id}).then(function(b){
                // console.log([osoblje2]);
                return new Promise(function(resolve,reject){resolve(b);});
            })
        );
		Promise.all(terminListaPromisea).then(function(termin){
			var termin1=termin.filter(function(t){return t.id==1})[0];
			var termin2=termin.filter(function(t){return t.id==2})[0];
			
			Promise.all(salaListaPromisea).then(function(sala){
				var sala1=termin.filter(function(s){return s.id==1})[0];
				var sala2=termin.filter(function(s){return s.id==2})[0];
				
				rezervacijaListaPromisea.push(
					db.rezervacija.create({termin:termin1.id,sala:sala1.id, osoba:osoblje1.id}).then(function(d){
					return new Promise(function(resolve,reject){resolve(d);});
					})
				);
				
				rezervacijaListaPromisea.push(
					db.rezervacija.create({termin:termin2.id,sala:sala1.id, osoba:osoblje3.id}).then(function(e){
					return new Promise(function(resolve,reject){resolve(e);});
					})
				);
				
				Promise.all(rezervacijaListaPromisea).then(function(r){resolve(r)
				}).catch(function(err){console.log("Rezervacija greska "+err);});
			}).catch(function(err){console.log("Sala greska "+err);});		
		 }).catch(function(err){console.log("Termini greska "+err);});
	}).catch(function(err){console.log("Osoblje greska "+err);});   
    }); 
}

		
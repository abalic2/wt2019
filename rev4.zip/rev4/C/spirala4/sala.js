const Sequelize = require("sequelize");

// Sala{id,naziv:string,zaduzenaOsoba:integer FK}

/* prvi nacin 
module.exports = function(sequelize,DataTypes){
    const Sala = sequelize.define("sala",{
		id:Sequelize.INTEGER,  // provjeriti
        naziv:Sequelize.STRING,
        zaduzenaOsoba:Sequelize.INTEGER
    })
    return Sala;
}; */

/*drugi nacin */
module.exports = function(sequelize, DataTypes) {
    var Sala = sequelize.define('Sala', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        naziv: {
            type: Sequelize.STRING(50),
            unique: true,
            allowNull: false
        },
		// U nastavku je zakomentarisan dio gdje se definise FK - ovo je rijeseno u db.js sa db.sala.belongsTo(db.osoblje,{foreignKey:'zaduzenaOsoba'});
       /* zaduzenaOsoba: {
            type: Sequelize.INTEGER,
			allowNull: false,
			references: {
				model: 'osobljes', // 'osbljes' refers to table name osoblje 
				key: 'id', // 'id' refers to column name in osoblje table
			}
        }*/
    });
	
    return Sala;
};
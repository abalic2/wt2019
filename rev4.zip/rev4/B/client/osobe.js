window.onload = function() {
    Pozivi.ucitajOsobljeSaZazuecem()
};
setTimeout(function () { location.reload(1); }, 30000);
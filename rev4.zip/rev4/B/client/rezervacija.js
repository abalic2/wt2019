window.onload = function() {
  posaljiIzForme();
  Pozivi.ucitajSaServera();
  posajiZauzeca();
  Pozivi.ucitajOsoblje();
  Pozivi.ucitajSale(); 
};



let trenutniMjesec = new Date().getMonth();

function posaljiIzForme() {
  let sala = document.querySelector("select").value;
  let pocetak = document.getElementById("p").value;
  let kraj = document.getElementById("k").value;
  if (pocetak.trim() && kraj.trim()) {
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      trenutniMjesec,
      sala,
      pocetak,
      kraj
    );
  }
}

Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
let kalendarRef = document.getElementById("kalendar");
let dani = kalendarRef.getElementsByClassName("dan");
function posajiZauzeca() {
  for (let index = 0; index < dani.length; index++) {
    const dan = dani[index];
    dan.addEventListener(
      "click",
      function(ev) {
        let sala = document.getElementById("sale").value;
        let pocetak = document.getElementById("p").value;
        let kraj = document.getElementById("k").value;
        let predavac = document.getElementById("osobe").value;
       // if (dan.getElementsByClassName("slobodna").length != 0) {
          if (pocetak.trim() && kraj.trim()) {
            if (window.confirm("Da li zelite rezervisati ovaj termin?")) {
              if (document.getElementById("checkbox").checked == true) {
                Pozivi.upisiPeriodicnoZauzece(
                  index,
                  trenutniMjesec,
                  sala,
                  pocetak,
                  kraj,
                  predavac
                );
              } else
                Pozivi.upisiVanrednoZauzece(
                  index,
                  trenutniMjesec,
                  sala,
                  pocetak,
                  kraj,
                  predavac
                );
            //}
          }
        }
      },
      false
    );
  }
}



let promjenaSale = document.querySelector("select");
promjenaSale.addEventListener(
  "change",
  function(ev) {
    posaljiIzForme();
    Pozivi.ucitajSaServera();
  },
  false
);

let promjenaPocetka = document.getElementById("p");
promjenaPocetka.addEventListener(
  "input",
  function(ev) {
    posaljiIzForme();
    Pozivi.ucitajSaServera();
  },
  false
);

let promjenaKraja = document.getElementById("k");
promjenaKraja.addEventListener(
  "input",
  function(ev) {
    posaljiIzForme();
    Pozivi.ucitajSaServera();
  },
  false
);

let dugmePrethodni = document.getElementById("prethodni");
dugmePrethodni.addEventListener(
  "click",
  function(ev) {
    if (trenutniMjesec >= 1) {
      trenutniMjesec--;
      Kalendar.iscrtajKalendar(
        document.getElementById("kalendar"),
        trenutniMjesec
      );
      posaljiIzForme();
      posajiZauzeca();
      Pozivi.ucitajSaServera();
    }
  },
  false
);

let dugmeSljedeci = document.getElementById("sljedeci");
dugmeSljedeci.addEventListener(
  "click",
  function(ev) {
    if (trenutniMjesec <= 10) {
      trenutniMjesec++;
      Kalendar.iscrtajKalendar(
        document.getElementById("kalendar"),
        trenutniMjesec
      );
      posaljiIzForme();
      posajiZauzeca();
      Pozivi.ucitajSaServera();
    }
  },
  false
);

let dugmeAzuriraj = document.getElementById("azuriraj");
dugmeAzuriraj.addEventListener(
  "click",
  function(ev) {
    posaljiIzForme();
    Pozivi.ucitajSaServera();
  },
  false
);

let guiAzuriraj = document.getElementById("kalendar");
guiAzuriraj.addEventListener(
  "onchange",
  function(ev) {
    posaljiIzForme();
    Pozivi.ucitajSaServera();
  },
  false
);
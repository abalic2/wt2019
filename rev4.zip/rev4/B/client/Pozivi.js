let Pozivi = (function() {
  function ucitajSaServeraImpl() {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        let zauzeca = JSON.parse(ajax.responseText);
        let periodicna = zauzeca.periodicna;
        let vanredna = zauzeca.vanredna;
        Kalendar.ucitajPodatke(periodicna, vanredna);
      } else if (ajax.readyState == 4) console.log(ajax.status);
    };
    ajax.open("POST", "http://localhost:8080/rezervacija");
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send();
  }

  function upisiVanrednoZauzeceImpl(
    dan,
    mjesec,
    sala,
    pocetak,
    kraj,
    predavac
  ) {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        alert(this.responseText);
        ucitajSaServeraImpl();
      } else if (ajax.readyState == 4) console.log(ajax.status);
    };
    ajax.open("POST", "http://localhost:8080/dodajRezervaciju");
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(
      "dan=" +
        (dan + 1) +
        "&mjesec=" +
        (mjesec + 1) +
        "&naziv=" +
        sala +
        "&pocetak=" +
        pocetak +
        "&kraj=" +
        kraj +
        "&predavac=" +
        predavac
    );
  }

  function upisiPeriodicnoZauzeceImpl(dan, mjesec, sala, pocetak, kraj, predavac) {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        alert(this.responseText);
        ucitajSaServeraImpl();
      } else if (ajax.readyState == 4) console.log(ajax.status);
    };
    ajax.open("POST", "http://localhost:8080/dodajPeriodicnuRezervaciju");
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send(
      "dan=" +
        (dan + 1) +
        "&mjesec=" +
        (mjesec + 1) +
        "&naziv=" +
        sala +
        "&pocetak=" +
        pocetak +
        "&kraj=" +
        kraj +
        "&predavac=" +
        predavac
    );
  }

  function ucitajSlikeImpl(brojPocetka) {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        let slike = JSON.parse(ajax.responseText);
        if ((slike[0] || slike[1] || slike[2]) == undefined)
          document.getElementById("sljedeciPocetna").disabled = true;
        else {
          Slike.slikeNaprijed(slike[0], slike[1], slike[2]);
        }
      } else if (ajax.readyState == 4) console.log(ajax.status);
    };
    ajax.open("POST", "http://localhost:8080/ucitajSlike");
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send("brojPocetka=" + brojPocetka);
  }

  function ucitajBrowserImpl() {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        document.getElementById("browserInfo").innerHTML = ajax.responseText;
      } else if (ajax.readyState == 4) console.log(ajax.status);
    };
    ajax.open("POST", "http://localhost:8080/getBrowser");
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send();
  }

  function ucitajSaleImpl() {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        let sale = JSON.parse(ajax.responseText);
        var sel = document.getElementById("sale");
        for (var i = 0; i < sale.length; i++) {
          var opt = document.createElement("option");
          opt.appendChild(
            document.createTextNode(sale[i].naziv)
          );
          opt.value = sale[i].id;
          sel.appendChild(opt);
        }
      } else if (ajax.readyState == 4) console.log(ajax.status);
    };
    ajax.open("GET", "http://localhost:8080/sveSale");
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send();
  }

  function ucitajOsobljeImpl() {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        let osobe = JSON.parse(ajax.responseText);
        var sel = document.getElementById("osobe");
        for (var i = 0; i < osobe.length; i++) {
          var opt = document.createElement("option");
          opt.appendChild(
            document.createTextNode(osobe[i].ime + " " + osobe[i].prezime)
          );
          opt.value = osobe[i].id;
          sel.appendChild(opt);
        }
      } else if (ajax.readyState == 4) console.log(ajax.status);
    };
    ajax.open("GET", "http://localhost:8080/osoblje");
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send();
  }

  function ucitajOsobljeSaZazuecemImpl() {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
      if (ajax.readyState == 4 && ajax.status == 200) {
        let osobe = JSON.parse(ajax.responseText);
        var list = document.getElementById("listaOsoba");
        for (var i = 0; i < osobe.length; i++) {
          var entry = document.createElement('li');
          entry.appendChild(document.createTextNode(osobe[i].ime + " " + osobe[i].prezime + " - " +osobe[i].sala));
          list.appendChild(entry);
        }
      } else if (ajax.readyState == 4) console.log(ajax.status);
    };
    ajax.open("GET", "http://localhost:8080/osobljeSaZauzecem");
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send();
  }

  return {
    ucitajSaServera: ucitajSaServeraImpl,
    upisiVanrednoZauzece: upisiVanrednoZauzeceImpl,
    upisiPeriodicnoZauzece: upisiPeriodicnoZauzeceImpl,
    ucitajSlike: ucitajSlikeImpl,
    ucitajBrowser: ucitajBrowserImpl,
    ucitajSale: ucitajSaleImpl,
    ucitajOsoblje: ucitajOsobljeImpl,
    ucitajOsobljeSaZazuecem : ucitajOsobljeSaZazuecemImpl
  };
})();

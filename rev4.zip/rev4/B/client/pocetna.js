let broj = 0;
let slike = [];
window.onload = function() {
  Pozivi.ucitajBrowser();
  Pozivi.ucitajSlike(broj);
  document.getElementById("prethodniPocetna").disabled = true;
};
let dugmePrethodni = document.getElementById("prethodniPocetna");
dugmePrethodni.addEventListener(
  "click",
  function(ev) {
    broj -= 3;
    if (broj == 0) document.getElementById("prethodniPocetna").disabled = true;
    Slike.slikeNazad(broj);
    document.getElementById("sljedeciPocetna").disabled = false;
  },
  false
);

let dugmeSljedeci = document.getElementById("sljedeciPocetna");
dugmeSljedeci.addEventListener(
  "click",
  function(ev) {
    document.getElementById("prethodniPocetna").disabled = false;
    broj += 3;
    Pozivi.ucitajSlike(broj);
  },
  false
);

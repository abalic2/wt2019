let Slike = (function() {
  let slike = [];
  let index = 0;
  function slikeNazadImpl(broj) {
    document.getElementById("slika1").src =
      "http://localhost:8080/images/" + slike[broj];
    document.getElementById("slika2").src =
      "http://localhost:8080/images/" + slike[broj + 1];
    document.getElementById("slika3").src =
      "http://localhost:8080/images/" + slike[broj + 2];
  }

  function slikeNaprijedImpl(slika1, slika2, slika3) {
    if (slika1 == null)
      document.getElementById("slika1").src =
        "https://upload.wikimedia.org/wikipedia/commons/0/03/Flag_Blank.svg";
    else {
      document.getElementById("slika1").src =
        "http://localhost:8080/images/" + slika1;
      slike[index] = slika1;
      index++;
    }
    if (slika2 == null) {
      document.getElementById("slika2").src =
        "https://upload.wikimedia.org/wikipedia/commons/0/03/Flag_Blank.svg";
      document.getElementById("sljedeciPocetna").disabled = true;
    } else {
      document.getElementById("slika2").src =
        "http://localhost:8080/images/" + slika2;
      slike[index] = slika2;
      index++;
    }
    if (slika3 == null) {
      document.getElementById("slika3").src =
        "https://upload.wikimedia.org/wikipedia/commons/0/03/Flag_Blank.svg";
      document.getElementById("sljedeciPocetna").disabled = true;
    } else {
      document.getElementById("slika3").src =
        "http://localhost:8080/images/" + slika3;
      slike[index] = slika3;
      index++;
    }
  }

  return {
    slikeNazad: slikeNazadImpl,
    slikeNaprijed: slikeNaprijedImpl
  };
})();

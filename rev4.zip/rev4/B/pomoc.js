const redovneRezervacija = await db.rezervacija.findAll({
    where: { termin: termin.id },
    attributes: ["sala", "osoba"]
  });
  redovneRezervacija.forEach(async rezervacija => {
    const sala = await db.sala.findOne({
      where: { id: rezervacija.sala }
    });
    const osoba = await db.osoblje.findOne({
      where: { id: rezervacija.osoba }
    });
      db.termin.create({
        redovni: false,
        dan: null,
        datum: datum,
        semestar: null,
        pocetak: "12:00",
        kraj: "14:00"
      });
    


    try {
      const user = await db.rezervacija.create({
        termin: termin.id, sala: sala.id, osoba: osoba.id
      });

    } catch (err) {
      // print the error details
      console.log(err, termin.id);
    }
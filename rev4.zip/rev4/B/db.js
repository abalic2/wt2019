const Sequelize = require("sequelize");
const sequelize = new Sequelize("DBWT19","root","root",{host:"127.0.0.1",dialect:"mysql",logging:false});
const db={};

db.Sequelize = Sequelize;  
db.sequelize = sequelize;

db.osoblje = sequelize.import(__dirname+'/models/osoblje.js');
db.rezervacija = sequelize.import(__dirname+'/models/rezervacija.js');
db.sala = sequelize.import(__dirname+'/models/sala.js');
db.termin = sequelize.import(__dirname+'/models/termin.js');

db.osoblje.hasMany(db.rezervacija,{as:'osobe',foreignKey:'osoba'});
db.termin.belongsTo(db.rezervacija,{as:'termini',foreignKey:'termin'});
db.sala.hasMany(db.rezervacija,{as:'sale',foreignKey:'sala'});
db.osoblje.hasOne(db.sala,{as: 'zaduzenaOsobe',foreignKey:'zaduzenaOsoba'});

module.exports=db;
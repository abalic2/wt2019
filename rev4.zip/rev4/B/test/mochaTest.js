var expect = require("chai").expect;
let chai = require('chai');
var request = require("request");
assert = require("assert");
let chaiHttp = require('chai-http');
let should = chai.should();

it("Main page status", function(done) {
  request("http://localhost:8080", function(error, response, body) {
    expect(response.statusCode).to.equal(200);
    done();
  });
});

it("Nesto page content", function(done) {
  request("http://localhost:8080/nesto", function(error, response, body) {
    expect(response.statusCode).to.equal(404);
    done();
  });
});

it("dodajRezervaciju send right data", function(done) {
  request("http://localhost:8080/dodajRezervaciju", function(
    error,
    request,
    response,
    body
  ) {
    expect(request).to.have.header(
      "content-type",
      "application/x-www-form-urlencoded"
    );
    done();
  });
});

it("Sale API content", function(done) {
  request("http://localhost:8080/sveSale", function(error, response, body) {
    response.body.should.have.property('id');
    done();
  });
});

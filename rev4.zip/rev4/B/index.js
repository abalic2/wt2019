const express = require("express");
const path = require("path");
const fs = require("fs");
var bodyParser = require("body-parser");
const browser = require("browser-detect");
const db = require("./db.js");
let chrome = 0;
let mozila = 0;
let ips = [];

const app = express();

app.use(express.static("client"));
app.use("/images", express.static(path.join(__dirname, "public/image")));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "client/pocetna.html"));
});

app.get("/sale", (req, res) => {
  res.sendFile(path.join(__dirname, "client/sale.html"));
});

app.get("/unos", (req, res) => {
  res.sendFile(path.join(__dirname, "client/unos.html"));
});

app.get("/rezervacija", (req, res) => {
  res.sendFile(path.join(__dirname, "client/rezervacija.html"));
});

app.get("/osobe", (req, res) => {
  res.sendFile(path.join(__dirname, "client/osobe.html"));
});

app.post("/ucitajSlike", (req, res) => {
  let slike = [];
  let broj = Number(req.body.brojPocetka);
  fs.readdir("public/image", (err, files) => {
    if (err) throw err;
    for (let index = broj; index < broj + 3; index++) {
      slike.push(files[index]);
    }
    res.send(slike);
  });
});

app.post("/getBrowser", (req, res) => {
  const result = browser(req.headers["user-agent"]);
  let ip = req.ip;
  if (result.name == "chrome" && ips.indexOf(ip) === -1) chrome++;
  if (result.name == "mozilla" && ips.indexOf(ip) === -1) mozila++;
  if (ips.indexOf(ip) === -1) ips.push(ip);
  res.send(
    "Broj posjetilaca sa Chrome: " +
      chrome +
      " a sa Mozilla: " +
      mozila +
      " <br> Broj posjetilaca sa različitim ip adresama: " +
      ips.length
  );
});

app.get("/osoblje", async (req, res) => {
  try {
    const osobe = await db.osoblje.findAll({
      attributes: ["ime", "prezime", "id"]
    });
    res.send(JSON.stringify(osobe));
  } catch (error) {
    res.status(400).send({ error: error.message });
  }
});

app.get("/sveSale", async (req, res) => {
  try {
    const sale = await db.sala.findAll({
      attributes: ["naziv", "id"]
    });
    res.send(JSON.stringify(sale));
  } catch (error) {
    res.status(400).send({ error: error.message });
  }
});

app.post("/rezervacija", async (req, res) => {
  let Zauzeca = { vanredna: [], periodicna: [] };
  const terminRezervacije = await db.termin.findAll({
    attributes: ["dan", "semestar", "pocetak", "kraj", "id", "redovni", "datum"]
  });
  terminRezervacije.forEach(async termin => {
    const redovneRezervacija = await db.rezervacija.findAll({
      where: { termin: termin.id },
      attributes: ["sala", "osoba"]
    });
    redovneRezervacija.forEach(async rezervacija => {
      const sala = await db.sala.findOne({
        where: { id: rezervacija.sala }
      });
      const osoba = await db.osoblje.findOne({
        where: { id: rezervacija.osoba }
      });
      var pocetak = termin.pocetak.substring(0, 5);
      var kraj = termin.kraj.substring(0, 5);
      if (termin.redovni) {
        let periodicnoZauzece = {
          dan: termin.dan,
          semestar: termin.semestar,
          pocetak: pocetak,
          kraj: kraj,
          naziv: sala.id,
          predavac: osoba.id
        };
        Zauzeca.periodicna.push(periodicnoZauzece);
      } else {
        let varednoZauzece = {
          datum: termin.datum,
          pocetak: pocetak,
          kraj: kraj,
          naziv: sala.id,
          predavac: osoba.id
        };
        Zauzeca.vanredna.push(varednoZauzece);
      }
    });
  });
  setTimeout(() => {
    let novoZauzece = JSON.stringify(Zauzeca);
    res.send(novoZauzece);
  }, 100);
});


app.post("/dodajRezervaciju", async (req, res) => {
  let odgovor = "Sala uspjesno rezervisana";
  let yyyy = new Date().getFullYear();
  let dd = req.body.dan;
  let mm = req.body.mjesec;
  if (dd / 10 < 1) dd = "0" + dd;
  if (mm / 10 < 1) mm = "0" + mm;
  let datum = dd + "." + mm + "." + yyyy;
  let d = new Date(datum);
    dan = d.getDay();
  let index = 1;
  const terminRezervacije = await db.termin.findAll({
    attributes: ["dan", "semestar", "pocetak", "kraj", "id", "redovni", "datum"]
  });
  terminRezervacije.forEach(async termin => {
    index++;
    const vanredneRezervacija = await db.rezervacija.findAll({
      where: { termin: termin.id },
      attributes: ["sala", "osoba"]
    });
    vanredneRezervacija.forEach(async rezervacija => {
      const sala = await db.sala.findOne({
        where: { id: rezervacija.sala }
      });
      const osoba = await db.osoblje.findOne({
        where: { id: rezervacija.osoba }
      });
      if (!termin.redovni) {
        if (
          termin.datum == datum &&
          imaLiPresjekaVremena(
            req.body.pocetak,
            req.body.kraj,
            termin.pocetak.substring(0, 5),
            termin.kraj.substring(0, 5)
          ) &&
          sala.id == req.body.naziv
        ) {
          odgovor =
            "Sala je već rezervisana od strane " +
            osoba.ime +
            " " +
            osoba.prezime;
        }
      }
    });
  });
  db.termin.create({
    redovni: false,
    dan: null,
    datum: datum,
    semestar: null,
    pocetak: req.body.pocetak,
    kraj: req.body.kraj
  });
  db.rezervacija.create({
    termin: index,
    sala: req.body.naziv,
    osoba: req.body.predavac
  });

  setTimeout(() => {
    let novoZauzece = JSON.stringify(odgovor);
    res.send(novoZauzece);
  }, 1000);
});
app.post("/dodajPeriodicnuRezervaciju",async (req, res) => {
  let odgovor = "Sala uspjesno rezervisana";
  let yyyy = new Date().getFullYear();
  let dd = req.body.dan;
  let mm = req.body.mjesec;
  if (dd / 10 < 1) dd = "0" + dd;
  if (mm / 10 < 1) mm = "0" + mm;
  let datum = mm + "." + dd + "." + yyyy;
  let d = new Date(datum);
    dan = d.getDay() -1;
  let semestar = req.body.mjesec;
  if (2 < semestar && semestar < 8) semestar = "ljetni";
    else semestar = "zimski";
  let index = 1;
  const terminRezervacije = await db.termin.findAll({
    attributes: ["dan", "semestar", "pocetak", "kraj", "id", "redovni", "datum"]
  });
  terminRezervacije.forEach(async termin => {
    index++;
    const vanredneRezervacija = await db.rezervacija.findAll({
      where: { termin: termin.id },
      attributes: ["sala", "osoba"]
    });
    vanredneRezervacija.forEach(async rezervacija => {
      const sala = await db.sala.findOne({
        where: { id: rezervacija.sala }
      });
      const osoba = await db.osoblje.findOne({
        where: { id: rezervacija.osoba }
      });
      if (termin.redovni) {
        if (
          termin.dan == dan &&
          imaLiPresjekaVremena(
            req.body.pocetak,
            req.body.kraj,
            termin.pocetak.substring(0, 5),
            termin.kraj.substring(0, 5)
          ) &&
          sala.id == req.body.naziv
        ) {
          odgovor =
            "Sala je već rezervisana od strane " +
            osoba.ime +
            " " +
            osoba.prezime;
        }
      }
    });
  });
  db.termin.create({
    redovni: true,
    dan: dan,
    datum: null,
    semestar: semestar,
    pocetak: req.body.pocetak,
    kraj: req.body.kraj
  });
  db.rezervacija.create({
    termin: index,
    sala: req.body.naziv,
    osoba: req.body.predavac
  });

  setTimeout(() => {
    let novoZauzece = JSON.stringify(odgovor);
    res.send(novoZauzece);
  }, 1000);
});

app.get("/osobljeSaZauzecem", async (req, res) => {
  let rezultat = [];
  let yyyy = new Date().getFullYear();
  let dd = new Date().getDate();
  let mm = new Date().getMonth() + 1;
  let dan = new Date().getDay();
  if (dd / 10 < 1) dd = "0" + dd;
  if (mm / 10 < 1) mm = "0" + mm;
  let datum = dd + "." + mm + "." + yyyy;
  let minutes = new Date().getMinutes();
  if (minutes / 10 < 1) minutes = "0" + minutes;
  let seconds = new Date().getSeconds();
  if (seconds / 10 < 1) seconds = "0" + seconds;
  let time = new Date().getHours() + ":" + minutes + ":" + seconds;
  try {
    const terminRezervacije = await db.termin.findAll({
      attributes: [
        "dan",
        "semestar",
        "pocetak",
        "kraj",
        "id",
        "redovni",
        "datum"
      ]
    });
    terminRezervacije.forEach(async termin => {
      const redovneRezervacija = await db.rezervacija.findAll({
        where: { termin: termin.id },
        attributes: ["sala", "osoba"]
      });
      redovneRezervacija.forEach(async rezervacija => {
        const sala = await db.sala.findOne({
          where: { id: rezervacija.sala }
        });
        const osoba = await db.osoblje.findOne({
          where: { id: rezervacija.osoba }
        });
        if (!termin.redovni) {
          if (
            datum == termin.datum &&
            termin.pocetak < time &&
            time < termin.kraj
          ) {
            var rez = {
              id: osoba.id,
              ime: osoba.ime,
              prezime: osoba.prezime,
              sala: sala.naziv
            };
            rezultat.push(rez);
          } 
        } else if (termin.redovni) {
          if (
            (dan = termin.dan && termin.pocetak < time && time < termin.kraj)
          ) {
            var rez = {
              id: osoba.id,
              ime: osoba.ime,
              prezime: osoba.prezime,
              sala: sala.naziv
            };
            rezultat.push(rez);
          } 
        }
      });
    });
    const sveOsobe = await db.osoblje.findAll({
    });
    setTimeout(() => {
      let niz = [];
      for (let index = 0; index < rezultat.length; index++) {
        niz[index] = rezultat[index].id;
      }
      sveOsobe.forEach(osoba => {
        if(!niz.includes(osoba.id)){
          var rez = {
            id: osoba.id,
            ime: osoba.ime,
            prezime: osoba.prezime,
            sala: "u kancelariji"
          };
          rezultat.push(rez);
        }
      });
      res.send(rezultat);
    }, 100);
  } catch (error) {
    res.status(400).send({ error: error.message });
  }
});

function imaLiPresjekaVremena(pocetak, kraj, zauzeto_pocetak, zauzeto_kraj) {
  let sat_pocetak = parseInt(pocetak.slice(0, 2));
  let sat_kraj = parseInt(kraj.slice(0, 2));
  let min_pocetak = parseInt(pocetak.slice(3));
  let min_kraj = parseInt(kraj.slice(3));

  let sat_p = parseInt(zauzeto_pocetak.slice(0, 2));
  let sat_k = parseInt(zauzeto_kraj.slice(0, 2));
  let min_p = parseInt(zauzeto_pocetak.slice(3));
  let min_k = parseInt(zauzeto_kraj.slice(3));

  let minute_sa_forme_pocetak = sat_pocetak * 60 + min_pocetak;
  let minute_sa_forme_kraj = sat_kraj * 60 + min_kraj;
  let minute_sa_zauzeca_pocetak = sat_p * 60 + min_p;
  let minute_sa_zauzeca_kraj = sat_k * 60 + min_k;

  if (minute_sa_forme_pocetak > minute_sa_forme_kraj) {
    return false;
  }

  if (
    (minute_sa_forme_pocetak >= minute_sa_zauzeca_kraj &&
      minute_sa_forme_kraj >= minute_sa_zauzeca_kraj) ||
    (minute_sa_forme_pocetak <= minute_sa_zauzeca_pocetak &&
      minute_sa_forme_kraj <= minute_sa_zauzeca_pocetak)
  ) {
    return false;
  }
  return true;
}

app.listen(8080);

const Sequelize = require("sequelize");

module.exports = function(sequelize, DataTypes) {
  const Sala = sequelize.define("sala", {
    id: {
      type: DataTypes.INTEGER(10),
      allowNull: false,
      autoIncrement: true,
      primaryKey: true
    },
    naziv: {
      type: DataTypes.STRING,
      allowNull: false
    },
    zaduzenaOsoba: {
      type: DataTypes.INTEGER(10),
      allowNull: false,
    }
  });
  return Sala;
};

const Sequelize = require("sequelize");

module.exports = function(sequelize, DataTypes) {
  const Termin = sequelize.define("termin", {
    id: {
      type: DataTypes.INTEGER(10),
      allowNull: false,
      autoIncrement: true,
      primaryKey: true
    },
    redovni: {
      type: DataTypes.BOOLEAN,
      allowNull: false
    },
    dan: {
      type: DataTypes.INTEGER(10)
    },
    datum: {
      type: DataTypes.STRING
    },
    semestar: {
      type: DataTypes.STRING
    },
    pocetak: Sequelize.TIME,
    kraj: Sequelize.TIME
  });
  return Termin;
};

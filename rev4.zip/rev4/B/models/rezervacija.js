const Sequelize = require("sequelize");

module.exports = function(sequelize, DataTypes) {
  const Rezervacija = sequelize.define("rezervacija", {
    id: {
      type: DataTypes.INTEGER(10),
      allowNull: false,
      autoIncrement: true,
      primaryKey: true
    },
    termin: {
      type: DataTypes.INTEGER(10),
      allowNull: false,
      unique: true,
    },
    sala: {
      type: DataTypes.INTEGER(10),
      allowNull: false,
    },
    osoba: {
      type: DataTypes.INTEGER(10),
      allowNull: false,
    }
  });
  return Rezervacija;
};

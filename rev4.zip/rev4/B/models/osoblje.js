const Sequelize = require("sequelize");

module.exports = function(sequelize,DataTypes){
    const Osoblje = sequelize.define("osoblje",{
        id: {
            type: DataTypes.INTEGER(10),
            allowNull: false,
            autoIncrement: true,
            primaryKey: true
          },
        ime:Sequelize.STRING,
        prezime:Sequelize.STRING,
        uloga:Sequelize.STRING
    })
    return Osoblje;
};
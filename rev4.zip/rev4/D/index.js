const express = require('express');
const bodyParser = require('body-parser');
const dbInit = require('./db/init').init;
const Kontroleri = require('./kontroleri');

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static('html'));
app.use(express.static('static'));

dbInit
    .then(() => Kontroleri.forEach(kontroler => kontroler(app)))
    .then(() => app.listen(8080));

module.exports = app;

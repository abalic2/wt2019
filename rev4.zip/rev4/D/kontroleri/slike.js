const fs = require('fs');

const PATH_SLIKE = 'static/img/';

function getUkupno(app) {
    app.get('/slike/ukupno', (req, res) => {
        fs.readdir(PATH_SLIKE, (err, slike) => {
            res.json({
                ukupno: err != null ? 0 : slike.filter(path => path.endsWith('.jpg') || path.endsWith('.jpeg') || path.endsWith('.png')).length
            });
        });
    });
}

function getNove(app) {
    app.get('/slike/:preuzeto', (req, res) => {
        const brojPoStranici = 3;
        const preuzeto = parseInt(req.params.preuzeto);

        fs.readdir(PATH_SLIKE, (err, slike) => {
            if (err)
                res.json({
                    greska: 'Greska!',
                    input: preuzeto
                });

            const ukupnoSlika = slike.length;
            const preostaloSlika = ukupnoSlika - preuzeto;

            if (preostaloSlika > 0)
                res.json({
                    slike: slike.slice(preuzeto, preostaloSlika >= brojPoStranici ? preuzeto + brojPoStranici : preuzeto + preostaloSlika).map(path => `img/${path}`)
                });
            else
                res.json({
                    slike: []
                });
        });
    });
}

module.exports = [
    getUkupno,
    getNove
];

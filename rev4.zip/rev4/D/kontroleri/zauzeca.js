const Util = require('./util');

function getZauzeca(app) {
    app.get('/zauzeca', (req, res) => {
        Util.trenutnaZauzecaPromise()
            .then(zauzeca => res.json(zauzeca));
    });
}

function postZauzeca(app) {
    app.post('/zauzeca', (req, res) => {
        Util.dodajZauzecePromise(req.body)
            .then(() => Util.trenutnaZauzecaPromise()
                .then(zauzeca => res.json(zauzeca)))
            .catch(err => res.json({poruka: err.message}));
    })
}

module.exports = [
    getZauzeca,
    postZauzeca
];

const db = require('../db/db');

function getSale(app) {
    app.get('/sale', (req, res) => db.sala.findAll().then(sale => res.json(sale)));
}

module.exports = [
    getSale
];

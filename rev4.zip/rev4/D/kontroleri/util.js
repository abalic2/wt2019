const db = require('../db/db');

const DANI = ['ponedjeljak', 'utorak', 'srijeda', 'četvrtak', 'petak', 'subota', 'nedjelja'];


function trenutnaZauzecaPromise() {
    const includeOptions = {
        include: [
            'rezervisaniTermin',
            'rezervacijaOsoba',
            'rezervisanaSala'
        ]
    };

    return db.rezervacija.findAll(includeOptions)
        .then(rezervacije => {
            let retVal = {
                periodicna: [],
                vanredna: []
            };

            rezervacije.forEach(rezervacija => {
                if (rezervacija.rezervisaniTermin.redovni)
                    retVal.periodicna.push({
                        dan: rezervacija.rezervisaniTermin.dan,
                        semestar: rezervacija.rezervisaniTermin.semestar,
                        pocetak: rezervacija.rezervisaniTermin.pocetak,
                        kraj: rezervacija.rezervisaniTermin.kraj,
                        naziv: rezervacija.rezervisanaSala.naziv,
                        predavac: `${rezervacija.rezervacijaOsoba.ime} ${rezervacija.rezervacijaOsoba.prezime}`
                    });
                else
                    retVal.vanredna.push({
                        datum: rezervacija.rezervisaniTermin.datum,
                        pocetak: rezervacija.rezervisaniTermin.pocetak,
                        kraj: rezervacija.rezervisaniTermin.kraj,
                        naziv: rezervacija.rezervisanaSala.naziv,
                        predavac: `${rezervacija.rezervacijaOsoba.ime} ${rezervacija.rezervacijaOsoba.prezime}`
                    });
            });

            return retVal;
        });
}

function poklapanjeVremena(prvi, drugi) {
    const prviPocetak = parseInt(prvi.pocetak.replace(':', ''));
    const prviKraj = parseInt(prvi.kraj.replace(':', ''));
    const drugiPocetak = parseInt(drugi.pocetak.replace(':', ''));
    const drugiKraj = parseInt(drugi.kraj.replace(':', ''));

    return drugiPocetak > drugiKraj || !((drugiPocetak >= prviKraj && drugiKraj > prviKraj) || (drugiKraj <= prviPocetak && drugiPocetak < prviPocetak));
}

function izvuciDan(stringDatum) {
    const dan = new Date(Date.parse(stringDatum.split('.').reverse().join('.'))).getDay();

    return dan > 0 ? dan - 1 : 6;
}

function izvuciSemestar(stringDatum) {
    return new Date(Date.parse(stringDatum.split('.').reverse().join('.'))).getMonth() < 10 ? 'zimski' : 'ljetni';
}

function poklapanjeDana(staro, novo) {
    // console.log('Staro: ');
    // console.log(staro);
    // console.log('Novo: ');
    // console.log(novo);

    let rezultat = undefined;

    if (staro.dan != null && novo.dan != null)
        rezultat = staro.dan === novo.dan && staro.semestar === novo.semestar;
    if (staro.datum != null && novo.datum != null)
        rezultat = staro.datum === novo.datum;
    if (staro.dan != null && novo.datum != null)
        rezultat = staro.dan === izvuciDan(novo.datum) && staro.semestar === izvuciSemestar(novo.datum);
    if (staro.datum != null && novo.dan != null)
        rezultat = izvuciDan(staro.datum) === novo.dan && izvuciSemestar(staro.datum) === novo.semestar;

    return rezultat;
}

function ispitajPoklapanje(staro, novo) {
    return poklapanjeDana(staro, novo) && poklapanjeVremena(staro, novo);
}

function dodajZauzecePromise(novo) {
    return trenutnaZauzecaPromise()
        .then(trenutna => {
            let mozdaZauzece = [...trenutna.periodicna, ...trenutna.vanredna]
                .filter(staro => ispitajPoklapanje(staro, novo))[0];

            if (!mozdaZauzece) {
                return db.termin
                    .findOrCreate({
                        where: {
                            redovni: novo.redovni,
                            dan: novo.redovni ? novo.dan : null,
                            semestar: novo.redovni ? novo.semestar : null,
                            datum: !novo.redovni ? novo.datum : null,
                            pocetak: novo.pocetak,
                            kraj: novo.kraj
                        }
                    })
                    .then(termin => {
                        return db.rezervacija.create({termin: termin[0].id, sala: novo.sala, osoba: novo.osoba});
                    });
            } else {
                throw new Error(`Sala ${mozdaZauzece.naziv} je za ${!!mozdaZauzece.dan ? DANI[mozdaZauzece.dan] : mozdaZauzece.datum} u terminu ${mozdaZauzece.pocetak}-${mozdaZauzece.kraj} rezervisana od strane ${mozdaZauzece.predavac}`);
            }
        });
}

module.exports = {
    trenutnaZauzecaPromise: trenutnaZauzecaPromise,
    dodajZauzecePromise: dodajZauzecePromise
};

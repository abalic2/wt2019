const ZauzecaKontroleri = require('./zauzeca');
const OsobljeKontroleri = require('./osobe');
const SaleKontroleri = require('./sale');
const SlikeKontroleri = require('./slike');

module.exports = [
    (app) => app.get('/', (req, res) => res.redirect('pocetna.html')),
    ...ZauzecaKontroleri,
    ...OsobljeKontroleri,
    ...SaleKontroleri,
    ...SlikeKontroleri
];

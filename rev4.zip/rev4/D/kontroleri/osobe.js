const db = require('../db/db');

function getOsoblje(app) {
    app.get('/osoblje', (req, res) => db.osoblje.findAll().then(osoblje => res.json(osoblje)))
}

module.exports = [
    getOsoblje
];

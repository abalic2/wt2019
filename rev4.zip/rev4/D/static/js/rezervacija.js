let osoblje = [];
let sale = [];

function trenutniMjesec() {
    const matches = document.getElementById('trenutni-mjesec').getAttribute('class').match(/mjesec_(\d+)/);
    return matches != null ? matches[1] : new Date().getMonth();
}

function trenutniSemestar() {
    const mjesec = trenutniMjesec();
    if (mjesec > 0 && mjesec < 6)
        return 'ljetni';
    else if (mjesec >= 6 && mjesec < 9)
        throw RangeError('Nastava se ne odrzava u julu, augustu i septembru.');

    return 'zimski';
}

function forma() {
    const salaSelect = document.getElementById('form-input-sala');
    const osobaSelect = document.getElementById('form-input-osoblje');

    return {
        naziv: salaSelect.options[salaSelect.selectedIndex].innerText,
        sala: salaSelect.options[salaSelect.selectedIndex].getAttribute('data-id'),
        redovni: document.getElementById('form-input-periodic').checked,
        pocetak: document.getElementById('form-input-time-from').value,
        kraj: document.getElementById('form-input-time-to').value,
        predavac: osobaSelect.options[osobaSelect.selectedIndex].innerText,
        osoba: osobaSelect.options[osobaSelect.selectedIndex].getAttribute('data-id')
    }
}

function render(zauzeca) {
    Kalendar.ucitajPodatke(zauzeca.periodicna, zauzeca.vanredna);

    try {
        ispisi(trenutniMjesec());
    } catch (e) {
        ispisi();
    }
}

function ispisi(mjesec = new Date().getMonth()) {
    Kalendar.iscrtajKalendar(document.getElementById('kalendar-desktop'), mjesec);
    Kalendar.obojiZauzeca(document.getElementById('kalendar-desktop'), mjesec, forma().naziv, forma().pocetak, forma().kraj);

    document.getElementById('btn-prev').addEventListener('click', () => ispisi(mjesec - 1));
    document.getElementById('btn-next').addEventListener('click', () => ispisi(mjesec + 1));

    for (let el of document.getElementsByClassName('sala'))
        el.addEventListener('click', function () {
            if (this.getElementsByClassName('zauzeta').length > 0)
                console.log('Termin zauzet!');

            const dan = parseInt(this.getElementsByClassName('dan')[0].innerText.toString());

            if (confirm('Da li želite rezervisati ovaj termin?'))
                zauzmi(dan);
        });
}

function zauzmi(dan) {
    const mjesec = trenutniMjesec();
    const datum = new Date(mjesec < 10 ? 2020 : 2019, mjesec, dan);
    const osnovno = {
        redovni: forma().redovni,
        pocetak: forma().pocetak,
        kraj: forma().kraj,
        sala: forma().sala,
        osoba: forma().osoba
    };

    const zauzece = forma().redovni ?
        {
            dan: datum.getDay() === 0 ? 6 : datum.getDay() - 1,
            semestar: trenutniSemestar(),
            ...osnovno
        } : {
            datum: `${parseInt(dan) < 10 ? '0' + dan : dan}.${datum.getMonth() + 1}.${datum.getFullYear()}`,
            ...osnovno
        };

    Pozivi.pokusajRezervisati(zauzece, render);
}

function popuniOsobljeSelect() {
    const osobljeSelect = document.getElementById('form-input-osoblje');

    osoblje.map(osoba => {
        let noviOption = document.createElement('option');

        noviOption.innerText = `${osoba.ime} ${osoba.prezime}`;
        noviOption.setAttribute('data-id', osoba.id);

        osobljeSelect.appendChild(noviOption);
    });
}

function popuniSaleSelect() {
    const saleSelect = document.getElementById('form-input-sala');

    sale.map(sala => {
        let noviOption = document.createElement('option');

        noviOption.innerText = sala.naziv;
        noviOption.setAttribute('data-id', sala.id);

        saleSelect.appendChild(noviOption);
    })
}

const originalOnLoad = window.onload;

window.onload = (e) => {
    if (typeof originalOnLoad === 'function')
        originalOnLoad(e);


    Pozivi.dohvatiSale(dohvaceneSale => {
        sale = dohvaceneSale;
        popuniSaleSelect();
    });
    Pozivi.dohvatiOsoblje(dohvacenoOsoblje => {
        osoblje = dohvacenoOsoblje;
        popuniOsobljeSelect();
    });
    Pozivi.dohvatiRezervacije(render);
};

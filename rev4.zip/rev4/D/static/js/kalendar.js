const Kalendar = (function () {
    const GODINA = new Date().getFullYear();
    const MJESECI = ['Januar', 'Februar', 'Mart', 'April', 'Maj', 'Juni', 'Juli', 'August', 'Septembar', 'Oktobar', 'Novembar', 'Decembar'];
    let periodicnaZauzeca = [];
    let vanrednaZauzeca = [];

    /**
     * Ogranicava vrijednost na raspon izmedju min i max.
     * U slucaju da je veca od max, vraca max.
     * U slucaju da je manja od min, vraca min.
     *
     * @param what {number} Vrijednost koju zelimo ograniciti
     * @param min {number} Minimalna vrijednost
     * @param max {number} Maximalna vrijednost
     * @returns {number} Ogranicenu vrijednost
     * @throws {TypeError} U slucaju da ijedan od parametara nije broj
     */
    const clamp = function (what, min, max) {
        if (isNaN(what) || isNaN(min) || isNaN(max))
            throw TypeError("Argumenti funkcije moraju biti brojevi");

        return (what > max) ? max :
            ((what < min) ? min : what);
    };

    /**
     * Vraca niz svih dana u mjesecu.
     *
     * @param year {number} Godina
     * @param month {number} Mjesec u godini
     * @returns {Date[]} Niz svih datuma koji pripadaju datom mjesecu i godini.
     */
    const daysOfMonth = function (year, month) {
        let days = [];

        for (let date = new Date(Date.UTC(year, month, 1)); date.getMonth() === month; date.setDate(date.getDate() + 1))
            days.push(new Date(date));

        return days;
    };

    /**
     * Funkcija konvertuje redni broj dana u sedmici iz naseg oblika (ponedjeljak prvi)
     * u oblik koji koristi {@link Date} klasa (nedjelja prva).
     *
     * @param day {number} 0-indeksirani redni broj dana u sedmici pocev od ponedjeljka
     * @returns {number} 0-indeksirani redni broj dana u sedmici pocev od nedjelje
     */
    const toDateDay = day => day === 6 ? 0 : day + 1;

    /**
     * Funkcija konvertuje redni broj dana u sedmici iz oblika koji koristi {@link Date} klasa
     * (nedjelja prva) u oblik koji mi koristimo (ponedjeljak prvi).
     *
     * @param day {number} 0-indeksirani redni broj dana u sedmici pocev od nedjelje
     * @returns {number} 0-indeksirani redni broj dana u sedmici pocev od ponedjeljka
     */
    const fromDateDay = day => day === 6 ? 0 : day + 1;

    /**
     * Redni broj trenutnog mjeseca.
     *
     * @param kalendarRef {HTMLElement} Kalendar
     * @returns {number} Redni broj trenutnog mjeseca
     */
    const trenutniMjesec = (kalendarRef) => {
        return MJESECI.indexOf(kalendarRef.getElementsByClassName('trenutni-mjesec')[0].innerText);
    };

    /**
     * Trenutni semestar u odnosu na mjesec
     *
     * @param mjesec {number} Indeks trenutnog mjeseca pocev od 0 za januar
     * @returns {string} Trenutni semestar
     * @throws {RangeError} U slucaju da je mjesec u periodu kada nema nastave
     */
    const trenutniSemestar = (mjesec) => {
        if (mjesec > 0 && mjesec < 6)
            return 'ljetni';
        else if (mjesec >= 6 && mjesec < 9)
            throw RangeError('Nastava se ne odrzava u julu, augustu i septembru.');

        return 'zimski';
    };

    /**
     * Pretvara datum vanrednog zauzeca u {@link Date} objekat
     *
     * @param datum {string} Datum u formatu 'dd.mm.yyyy'
     * @returns {Date} Objekat koji predstavlja dati datum
     * @throws {SyntaxError} U slucaju da datum nije u odgovarajucem formatu
     */
    const parsirajDatum = (datum) => {
        if (!datum.match(/\d{1,2}\.\d{1,2}\.\d{4}/))
            throw SyntaxError(`Pogresan format datuma. Datum: ${datum}`);

        return new Date(Date.parse(datum.split('.').reverse().join('.')));
    };

    const ispitajPoklapanje = (pocetak, kraj, zauzece) => {
        const zauzecePocetak = parseInt(zauzece.pocetak.replace(':', ''));
        const zauzeceKraj = parseInt(zauzece.kraj.replace(':', ''));

        return !((pocetak >= zauzeceKraj && kraj > zauzeceKraj) || (kraj <= zauzecePocetak && pocetak < zauzecePocetak));
    };

    const obojiZauzeca = (kalendarRef, mjesec, sala, pocetak, kraj) => {
        pocetak = parseInt(pocetak.replace(':', ''));
        kraj = parseInt(kraj.replace(':', ''));

        try { trenutniSemestar(mjesec) } catch (e) { return; }
        if (trenutniMjesec(kalendarRef) !== mjesec)
            return;

        if (pocetak > kraj) {
            Array.from(kalendarRef.getElementsByClassName('sala')).forEach(sala => {
                sala.lastElementChild.classList.remove('slobodna');
                sala.lastElementChild.classList.add('zauzeta');
            });
            return;
        }

        Array.from(kalendarRef.getElementsByClassName('sala')).forEach(sala => {
            const cls = sala.lastElementChild.getAttribute('class');
            sala.lastElementChild.setAttribute('class', cls.replace('zauzeta', 'slobodna'));
        });

        periodicnaZauzeca.forEach(periodicno => {
            if (periodicno.semestar !== trenutniSemestar(mjesec) || periodicno.naziv !== sala || !ispitajPoklapanje(pocetak, kraj, periodicno))
                return;

            const dan = toDateDay(periodicno.dan);
            Array.from(kalendarRef.getElementsByClassName(`sedmica_${dan}`)).forEach(el => el.setAttribute('class', `zauzeta sedmica_${dan}`));
        });

        vanrednaZauzeca.forEach(vanredno => {
            const datum = parsirajDatum(vanredno.datum);

            if (datum.getMonth() < mjesec || datum.getMonth() > mjesec || vanredno.naziv !== sala || !ispitajPoklapanje(pocetak, kraj, vanredno))
                return;

            document.getElementById(`dan_${datum.getDate()}`).setAttribute('class', `zauzeta sedmica_${datum.getDay()}`);
        });
    };

    const ucitajPodatke = (periodicna, vanredna) => {
        periodicnaZauzeca = [...periodicna];
        vanrednaZauzeca = [...vanredna];
    };

    // =============
    // Funkcije za pomoc pri iscrtavanju kalendara
    // =============
    const iscrtajHeader = (mjesec) => {
        return `<thead>
                <tr>
                    <th colspan="7" id="trenutni-mjesec" class="trenutni-mjesec mjesec_${mjesec}"><h2>${MJESECI[mjesec]}</h2></th>
                </tr>
                <tr>
                    <th><h3>PON</h3></th>
                    <th><h3>UTO</h3></th>
                    <th><h3>SRI</h3></th>
                    <th><h3>ČET</h3></th>
                    <th><h3>PET</h3></th>
                    <th><h3>SUB</h3></th>
                    <th><h3>NED</h3></th>
                </tr>
                </thead>`;
    };

    const iscrtajFooter = (kalendarRef, mjesec) => {
        return `<tfoot>
                    <tr>
                        <td colspan="7">
                            <button id="btn-prev" class="dugme" ${mjesec === 0 ? 'disabled' : ''}>Prethodni</button>
                            <button id="btn-next" class="dugme" ${mjesec === 11 ? 'disabled' : ''}>Sljedeći</button>
                        </td>
                    </tr>
                </tfoot>`;
    };

    const iscrtajDan = (dan, slobodan) => {
        return `<td class="sala"><div class="dan">${dan.getDate()}</div><div id="dan_${dan.getDate()}" class="${slobodan ? 'slobodna' : 'zauzeta'} sedmica_${dan.getDay()}"></div></td>`;
    };

    const iscrtajTijelo = (prazniPocetak, dani, prazniKraj) => {
        const paddingPocetak = '<td></td>'.repeat(prazniPocetak);
        const paddingKraj = '<td></td>'.repeat(prazniKraj);

        const prvaSedmica = `<tr>${paddingPocetak}${dani.splice(0, 7 - prazniPocetak).map(dan => iscrtajDan(dan, true)).join('')}</tr>`;

        let sredina = '';

        while (dani.length > 7)
            sredina += `<tr>${dani.splice(0, 7).map(dan => iscrtajDan(dan, true)).join('')}</tr>`;

        const zadnjaSedmica = `<tr>${dani.map(dan => iscrtajDan(dan, true)).join('')}${paddingKraj}</tr>`;

        return `<tbody>${prvaSedmica}${sredina}${zadnjaSedmica}</tbody>`;
    };
    // =============

    const iscrtajKalendar = (kalendarRef, mjesec) => {
        mjesec = clamp(mjesec, 0, 11);

        const daniMjeseca = daysOfMonth(GODINA, mjesec);

        const prviDan = daniMjeseca[0].getDay();
        const zadnjiDan = daniMjeseca[daniMjeseca.length - 1].getDay();

        const prazniPocetak = prviDan > 0 ? prviDan - 1 : 6;
        const prazniKraj = zadnjiDan > 0 ? 7 - zadnjiDan : zadnjiDan;

        kalendarRef.innerHTML = `${iscrtajHeader(mjesec)}${iscrtajTijelo(prazniPocetak, daniMjeseca, prazniKraj)}${iscrtajFooter(kalendarRef, mjesec)}`;
    };

    return {
        obojiZauzeca: obojiZauzeca,
        ucitajPodatke: ucitajPodatke,
        iscrtajKalendar: iscrtajKalendar
    }
})();


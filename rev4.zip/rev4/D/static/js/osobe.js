const DEFAULT_LOKACIJA = 'u kancelariji';

let osoblje = [];

function napraviRed(osoba) {
    let noviRed = document.createElement('tr');
    let ime = document.createElement('td');
    let prezime = document.createElement('td');
    let uloga = document.createElement('td');
    let lokacija = document.createElement('td');

    ime.innerText = osoba.ime;
    prezime.innerText = osoba.prezime;
    uloga.innerText = osoba.uloga;
    lokacija.innerText = !!osoba.lokacija ? osoba.lokacija : DEFAULT_LOKACIJA;

    noviRed.appendChild(ime);
    noviRed.appendChild(prezime);
    noviRed.appendChild(uloga);
    noviRed.appendChild(lokacija);

    return noviRed;
}

function ispisiOsoblje() {
    const tabelaHeader = document.getElementById('table-osoblje');
    tabelaHeader.innerHTML = '<thead><tr><td>Ime</td><td>Prezime</td><td>Uloga</td><td>Lokacija</td></tr></thead>';

    osoblje.forEach(osoba => tabelaHeader.appendChild(napraviRed(osoba)));
}

function trenutnoZauzece(zauzece, trenutnoVrijemeInt) {
    return trenutnoVrijemeInt > parseInt(zauzece.pocetak.replace(':', '')) && trenutnoVrijemeInt < parseInt(zauzece.kraj.replace(':', ''));
}

function trenutniDatum(zauzece, trenutniDatumInt) {
    return parseInt(zauzece.datum.split('.').reverse().join('.').replace(/\./g, '')) === trenutniDatumInt;
}

function azurirajLokacije(zauzeca) {
    const trenutnoVrijeme = new Date();
    const sad = trenutnoVrijeme.getHours() * 100 + trenutnoVrijeme.getMinutes();
    const dan = trenutnoVrijeme.getDay() > 0 ? trenutnoVrijeme.getDay() - 1 : 6;
    const datum = trenutnoVrijeme.getDate() + (trenutnoVrijeme.getMonth() + 1) * 100 + trenutnoVrijeme.getFullYear() * 10000;

    const trenutnaZauzeca = [
        ...zauzeca.periodicna
            .filter(periodicno => periodicno.dan === dan && trenutnoZauzece(periodicno, sad))
            .map(periodicno => {
                return {
                    predavac: periodicno.predavac,
                    naziv: periodicno.naziv
                };
            }),
        ...zauzeca.vanredna
            .filter(vanredno => trenutniDatum(vanredno, datum) && trenutnoZauzece(vanredno, sad))
            .map(vanredno => {
                return {
                    predavac: vanredno.predavac,
                    naziv: vanredno.naziv
                }
            })
    ];

    osoblje = osoblje.map(osoba => {
        let mozdaZauzece = trenutnaZauzeca.filter(zauzece => zauzece.predavac === `${osoba.ime} ${osoba.prezime}`)[0];

        if (!!mozdaZauzece)
            osoba.lokacija = mozdaZauzece.naziv;
        else
            osoba.lokacija = DEFAULT_LOKACIJA;

        return osoba;
    });
}

function ispisiOsobljeSLokacijama() {
    Pozivi.dohvatiRezervacije(zauzeca => {
        azurirajLokacije(zauzeca);
        ispisiOsoblje();
    });
}

const originalOnLoad = window.onload;

window.onload = (e) => {
    if (typeof originalOnLoad === 'function')
        originalOnLoad(e);

    Pozivi.dohvatiOsoblje(dohvacenoOsoblje => {
        osoblje = dohvacenoOsoblje;
        ispisiOsobljeSLokacijama();

        window.setInterval(() => ispisiOsobljeSLokacijama(), 30000);
    });
};


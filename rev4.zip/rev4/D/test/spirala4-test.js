const {describe, it, beforeEach, afterEach} = require('mocha');
const chai = require('chai');
const expect = chai.expect;
const fail = chai.assert.fail;
const chaiHttp = require('chai-http');

const express = require('express');
const bodyParser = require('body-parser');
const dbInit = require('../db/init').init;
const Kontroleri = require('../kontroleri');

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static('html'));
app.use(express.static('static'));

chai.use(chaiHttp);

Kontroleri.forEach(kontroler => kontroler(app));

let server = require('http').createServer(app);

function defaultCreateAndUpdate(element) {
    element.createdAt = 1;
    element.updatedAt = 1;
    return element;
}

describe('Testovi', function () {
    beforeEach(function (done) {
        server.listen(8080, () => {
            console.log('Server listening');
            dbInit.then(() => done());
        });
    });

    afterEach(function (done) {
        server.close(() => done());
    });

    describe('baza podataka', function () {

        it('sadrzi sve podrazumijevane podatke nakon inicijalizacije', function (done) {
            const db = require('../db/db');

            const listaPromisea = [
                db.osoblje.findAndCountAll(),
                db.sala.findAndCountAll(),
                db.rezervacija.findAndCountAll(),
                db.termin.findAndCountAll()
            ];

            Promise.all(listaPromisea)
                .then(vrijednosti => {
                    vrijednosti.forEach(vrijednost => {
                        expect(vrijednost)
                            .to.be.an('object')
                            .that.all.keys('rows', 'count');
                        expect(vrijednost.rows)
                            .to.be.an('array')
                            .that.is.not.empty;
                        expect(vrijednost.count)
                            .to.be.a('number')
                            .that.is.greaterThan(0);
                    });
                })
                .then(() => done())
                .catch(() => fail());
        });

    });

    describe('osoblje kontroler', function () {

        it('vraca listu osoblja', function (done) {
            const expectedOsoblje = [
                {
                    id: 1,
                    ime: "Neko",
                    prezime: "Nekić",
                    uloga: "profesor",
                    createdAt: 1,
                    updatedAt: 1
                },
                {
                    id: 2,
                    ime: "Drugi",
                    prezime: "Neko",
                    uloga: "asistent",
                    createdAt: 1,
                    updatedAt: 1
                },
                {
                    id: 3,
                    ime: "Test",
                    prezime: "Test",
                    uloga: "asistent",
                    createdAt: 1,
                    updatedAt: 1
                }
            ];

            chai.request(server)
                .get('/osoblje')
                .end((err, res) => {
                    expect(res.status).to.be.eq(200);
                    expect(res.body.map(mem => {
                        mem.createdAt = 1;
                        mem.updatedAt = 1;
                        return mem;
                    }))
                        .to.be.an('array')
                        .that.has.same.deep.members(expectedOsoblje);
                    done();
                });
        });

    });

    describe('sale kontroler', function () {

        it('vraca listu sala', function (done) {
            const expectedSale = [
                {
                    id: 1,
                    naziv: "1-11",
                    zaduzenaOsoba: 1,
                    createdAt: 1,
                    updatedAt: 1
                },
                {
                    id: 2,
                    naziv: "1-15",
                    zaduzenaOsoba: 2,
                    createdAt: 1,
                    updatedAt: 1
                }
            ];

            chai.request(server)
                .get('/sale')
                .end((err, res) => {
                    expect(res.status).to.be.eq(200);
                    expect(res.body.map(defaultCreateAndUpdate))
                        .to.be.an('array')
                        .that.has.same.deep.members(expectedSale);
                    done();
                });
        });

    });

    describe('zauzeca kontroler', function () {

        beforeEach(function (done) {
            const db = require('../db/db');

            db.rezervacija
                .findAll({
                    where: {
                        id: {
                            [db.Op.gt]: 2
                        }
                    }
                })
                .then(rezervacije => {
                    // console.log(rezervacije);
                    return Promise.all(rezervacije.map(rezervacija => rezervacija.destroy()));
                })
                .then(() => done())
                .catch(() => done());
        });

        const defaultZauzeca = {
            periodicna: [
                {
                    dan: 0,
                    semestar: "zimski",
                    pocetak: "13:00:00",
                    kraj: "14:00:00",
                    naziv: "1-11",
                    predavac: "Test Test"
                }
            ],
            vanredna: [
                {
                    datum: "01.01.2020",
                    pocetak: "12:00:00",
                    kraj: "13:00:00",
                    naziv: "1-11",
                    predavac: "Neko Nekić"
                }
            ]
        };
        const sala1 = '1-11';
        const osoba1 = 'Neko Nekić';

        it('vraca sva zauzeca', function (done) {
            chai.request(server)
                .get('/zauzeca')
                .end((err, res) => {
                    expect(res.status).to.be.eq(200);
                    expect(res.body).to.be.an('object');
                    expect(res.body.vanredna)
                        .to.be.an('array')
                        .that.has.same.deep.members(defaultZauzeca.vanredna);
                    expect(res.body.periodicna)
                        .to.be.an('array')
                        .that.has.same.deep.members(defaultZauzeca.periodicna);
                    done();
                });
        });

        it('moze napraviti novo periodicno zauzece', function (done) {
            const novoPeriodicno = {
                redovni: true,
                dan: 1,
                semestar: 'zimski',
                pocetak: '12:00',
                kraj: '14:00',
                sala: 1,
                osoba: 1,
                naziv: sala1,
                predavac: osoba1
            };

            const ocekivanaKonacna = {
                vanredna: defaultZauzeca.vanredna,
                periodicna: [
                    ...defaultZauzeca.periodicna,
                    {
                        naziv: novoPeriodicno.naziv,
                        predavac: novoPeriodicno.predavac,
                        dan: novoPeriodicno.dan,
                        semestar: novoPeriodicno.semestar,
                        pocetak: novoPeriodicno.pocetak.toString() + ':00',
                        kraj: novoPeriodicno.kraj.toString() + ':00'
                    }
                ]
            };

            chai.request(server)
                .post('/zauzeca')
                .send(novoPeriodicno)
                .end(((err, res) => {
                    expect(res.status).to.be.eq(200);
                    expect(res.body).to.be.an('object');
                    expect(res.body.vanredna)
                        .to.be.an('array')
                        .that.has.same.deep.members(ocekivanaKonacna.vanredna);
                    expect(res.body.periodicna)
                        .to.be.an('array')
                        .that.has.same.deep.members(ocekivanaKonacna.periodicna);
                    done();
                }));
        });

        it('moze napraviti novo vanredno zauzece', function (done) {
            const novoVanredno = {
                redovni: false,
                datum: '02.02.2020',
                pocetak: '12:00',
                kraj: '14:00',
                sala: 1,
                osoba: 1,
                naziv: sala1,
                predavac: osoba1
            };

            const ocekivanaKonacna = {
                vanredna: [
                    ...defaultZauzeca.vanredna,
                    {
                        naziv: novoVanredno.naziv,
                        predavac: novoVanredno.predavac,
                        datum: novoVanredno.datum,
                        pocetak: novoVanredno.pocetak.toString() + ':00',
                        kraj: novoVanredno.kraj.toString() + ':00'
                    }
                ],
                periodicna: defaultZauzeca.periodicna
            };

            chai.request(server)
                .post('/zauzeca')
                .send(novoVanredno)
                .end(((err, res) => {
                    expect(res.status).to.be.eq(200);
                    expect(res.body).to.be.an('object');
                    expect(res.body.vanredna)
                        .to.be.an('array')
                        .that.has.same.deep.members(ocekivanaKonacna.vanredna);
                    expect(res.body.periodicna)
                        .to.be.an('array')
                        .that.has.same.deep.members(ocekivanaKonacna.periodicna);
                    done();
                }));
        });

        it('ne moze napraviti novo periodicno zauzece ako postoji preklapanje sa periodicnim', function (done) {
            const novoPeriodicno = {
                redovni: true,
                dan: 0,
                semestar: 'zimski',
                pocetak: '12:00',
                kraj: '14:00',
                sala: 1,
                osoba: 1,
                naziv: sala1,
                predavac: osoba1
            };

            chai.request(server)
                .post('/zauzeca')
                .send(novoPeriodicno)
                .end((err, res) => {
                    expect(res.status).to.be.eq(200);
                    expect(res.body)
                        .to.be.an('object')
                        .that.has.all.keys('poruka');
                    expect(res.body.poruka)
                        .to.be.a('string')
                        .that.contains(defaultZauzeca.periodicna[0].predavac)
                        .and.that.contains(defaultZauzeca.periodicna[0].naziv);
                    done();
                });
        });

        it('ne moze napraviti novo periodicno zauzece ako postoji preklapanje sa vanrednim', function (done) {
            const novoPeriodicno = {
                redovni: true,
                dan: 2,
                semestar: 'zimski',
                pocetak: '12:00',
                kraj: '14:00',
                sala: 1,
                osoba: 1,
                naziv: sala1,
                predavac: osoba1
            };

            chai.request(server)
                .post('/zauzeca')
                .send(novoPeriodicno)
                .end((err, res) => {
                    expect(res.status).to.be.eq(200);
                    expect(res.body)
                        .to.be.an('object')
                        .that.has.all.keys('poruka');
                    expect(res.body.poruka)
                        .to.be.a('string')
                        .that.contains(defaultZauzeca.vanredna[0].predavac)
                        .and.that.contains(defaultZauzeca.vanredna[0].naziv);
                    done();
                });
        });

        it('ne moze napraviti novo vanredno zauzece ako postoji preklapanje sa vanrednim', function (done) {
            const novoVanredno = {
                redovni: false,
                datum: '01.01.2020',
                pocetak: '12:00',
                kraj: '14:00',
                sala: 1,
                osoba: 1,
                naziv: sala1,
                predavac: osoba1
            };

            chai.request(server)
                .post('/zauzeca')
                .send(novoVanredno)
                .end((err, res) => {
                    expect(res.status).to.be.eq(200);
                    expect(res.body)
                        .to.be.an('object')
                        .that.has.all.keys('poruka');
                    expect(res.body.poruka)
                        .to.be.a('string')
                        .that.contains(defaultZauzeca.vanredna[0].predavac)
                        .and.that.contains(defaultZauzeca.vanredna[0].naziv);
                    done();
                });
        });

        it('ne moze napraviti novo vanredno zauzece ako postoji preklapanje sa periodicnim', function (done) {
            const novoVanredno = {
                redovni: false,
                datum: '06.01.2020',
                pocetak: '12:00',
                kraj: '14:00',
                sala: 1,
                osoba: 1,
                naziv: sala1,
                predavac: osoba1
            };

            chai.request(server)
                .post('/zauzeca')
                .send(novoVanredno)
                .end((err, res) => {
                    expect(res.status).to.be.eq(200);
                    expect(res.body)
                        .to.be.an('object')
                        .that.has.all.keys('poruka');
                    expect(res.body.poruka)
                        .to.be.a('string')
                        .that.contains(defaultZauzeca.periodicna[0].predavac)
                        .and.that.contains(defaultZauzeca.periodicna[0].naziv);
                    done();
                });
        });

    });
});

const db = require('./db');

module.exports.init = db.sequelize.sync({force: true})
    .then(() => dataInit())
    .catch(reason => console.error(reason));

function dataInit() {
    const osobljePromiseList = [
        db.osoblje.create({id: 1, ime: 'Neko', prezime: 'Nekić', uloga: 'profesor'}),
        db.osoblje.create({id: 2, ime: 'Drugi', prezime: 'Neko', uloga: 'asistent'}),
        db.osoblje.create({id: 3, ime: 'Test', prezime: 'Test', uloga: 'asistent'})
    ];
    const salePromiseList = [
        db.sala.create({id: 1, naziv: '1-11', zaduzenaOsoba: 1}),
        db.sala.create({id: 2, naziv: '1-15', zaduzenaOsoba: 2})
    ];
    const terminiPromiseList = [
        db.termin.create({id: 1, redovni: false, dan: null, datum: '01.01.2020', semestar: null, pocetak: '12:00', kraj: '13:00'}),
        db.termin.create({id: 2, redovni: true, dan: 0, datum: null, semestar: 'zimski', pocetak: '13:00', kraj: '14:00'})
    ];
    const rezervacijePromiseList = [
        db.rezervacija.create({id: 1, termin: 1, sala: 1, osoba: 1}),
        db.rezervacija.create({id: 2, termin: 2, sala: 1, osoba: 3})
    ];

    return new Promise((resolve, reject) => {
        Promise.all(osobljePromiseList)
            .then(() => Promise.all(salePromiseList).then(all => resolve(all)))
            .then(() => Promise.all(terminiPromiseList).then(all => resolve(all)))
            .then(() => Promise.all(rezervacijePromiseList).then(all => resolve(all)))
            .catch(reason => reject(reason));
    });
}

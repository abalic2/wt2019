const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('osoblje', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            unique: true,
            allowNull: false,
            autoIncrement: true
        },
        ime: DataTypes.STRING,
        prezime: DataTypes.STRING,
        uloga: DataTypes.STRING
    }, {
        sequelize,
        tableName: 'osoblje',
        underscored: true
    });
};

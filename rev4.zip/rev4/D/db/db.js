const Sequelize = require('sequelize');
const sequelize = new Sequelize('DBWT19', 'root', 'root', {host: '127.0.0.1', dialect: 'mysql', logging: false});
const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;
db.Op = Sequelize.Op;

// Import modela
db.osoblje = sequelize.import(__dirname + '/osoblje.js');
db.rezervacija = sequelize.import(__dirname + '/rezervacija.js');
db.termin = sequelize.import(__dirname + '/termin.js');
db.sala = sequelize.import(__dirname + '/sala.js');

// Definicije relacija
db.osoblje.hasMany(db.rezervacija, {foreignKey: {name: 'osoba'}});
db.sala.hasMany(db.rezervacija, {foreignKey: {name: 'sala'}});
db.rezervacija.belongsTo(db.termin, {as: 'rezervisaniTermin', foreignKey: {name: 'termin'}});
db.rezervacija.belongsTo(db.osoblje, {as: 'rezervacijaOsoba', foreignKey: {name: 'osoba'}});
db.rezervacija.belongsTo(db.sala, {as: 'rezervisanaSala', foreignKey: {name: 'sala'}});
db.osoblje.hasOne(db.sala, {foreignKey: {name: 'zaduzenaOsoba'}});


module.exports = db;

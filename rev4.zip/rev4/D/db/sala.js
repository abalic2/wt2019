const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('sala', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            unique: true,
            allowNull: false,
            autoIncrement: true
        },
        naziv: Sequelize.STRING,
        zaduzenaOsoba: Sequelize.INTEGER
    }, {
        sequelize,
        tableName: 'sala',
        underscored: true
    });
};

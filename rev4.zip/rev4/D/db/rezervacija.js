const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('rezervacija', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            unique: true,
            allowNull: false,
            autoIncrement: true
        },
        termin: {
            type: Sequelize.INTEGER,
            unique: true
        },
        sala: Sequelize.INTEGER,
        osoba: Sequelize.INTEGER
    }, {
        sequelize,
        tableName: 'rezervacija',
        underscored: true
    });
};

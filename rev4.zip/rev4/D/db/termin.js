const Sequelize = require('sequelize');

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('termin', {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            unique: true,
            allowNull: false,
            autoIncrement: true
        },
        redovni: Sequelize.BOOLEAN,
        dan: Sequelize.INTEGER,
        datum: Sequelize.STRING,
        semestar: {
            type: Sequelize.STRING,
            validate: {
                isIn: ['zimski', 'ljetni']
            }
        },
        pocetak: Sequelize.TIME,
        kraj: Sequelize.TIME
    }, {
        sequelize,
        tableName: 'termin',
        underscored: true
    });
};
